package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.chess.model.GameMode
import com.example.chess.ui.ChessViewModel
import com.example.chess.ui.Screen
import com.example.chess.ui.screens.DifficultyScreen
import com.example.chess.ui.screens.GameScreen
import com.example.chess.ui.screens.HomeScreen
import com.example.chess.ui.screens.OpeningScreen
import com.example.chess.ui.screens.SettingsScreen
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import com.example.chess.ui.theme.ChessAppTheme
import com.example.chess.ui.theme.ChessWarmWhite

class MainActivity : ComponentActivity() {

    private val viewModel: ChessViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChessAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ChessWarmWhite
                ) {
                    ChessApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun ChessApp(viewModel: ChessViewModel) {
    val state by viewModel.uiState.collectAsState()

    Crossfade(
        targetState = state.currentScreen,
        animationSpec = tween(durationMillis = 300, easing = LinearOutSlowInEasing),
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            Screen.OPENING -> {
                OpeningScreen(
                    onAnimationFinished = {
                        viewModel.navigateTo(Screen.HOME)
                    }
                )
            }

            Screen.HOME -> {
            HomeScreen(
                selectedDifficulty = state.difficulty,
                selectedTimeControl = state.timeControl,
                selectedTheme = state.theme,
                selectedPieceStyle = state.pieceStyle,
                onPlayVsAi = {
                    viewModel.navigateTo(Screen.DIFFICULTY_SELECTION)
                },
                onPlayWithFriend = {
                    viewModel.startNewGame(GameMode.LOCAL_FRIEND)
                },
                onSelectDifficulty = {
                    viewModel.navigateTo(Screen.DIFFICULTY_SELECTION)
                },
                onOpenSettings = {
                    viewModel.navigateTo(Screen.SETTINGS)
                },
                onSelectTimeControl = { tc ->
                    viewModel.selectTimeControl(tc)
                },
                onSelectTheme = { theme ->
                    viewModel.selectTheme(theme)
                }
            )
        }

        Screen.DIFFICULTY_SELECTION -> {
            DifficultyScreen(
                currentDifficulty = state.difficulty,
                onDifficultySelected = { diff ->
                    viewModel.selectDifficulty(diff)
                },
                onStartGame = {
                    viewModel.startNewGame(GameMode.VS_AI, state.difficulty, state.timeControl)
                },
                onBack = {
                    viewModel.navigateTo(Screen.HOME)
                }
            )
        }

        Screen.GAME -> {
            GameScreen(
                state = state,
                onSquareClicked = { sq ->
                    viewModel.onSquareClicked(sq)
                },
                onPromotionPieceSelected = { pt ->
                    viewModel.onPromotionPieceSelected(pt)
                },
                onDismissPromotionDialog = {
                    viewModel.dismissPromotionDialog()
                },
                onUndo = {
                    viewModel.undoMove()
                },
                onRequestDraw = {
                    viewModel.requestDraw()
                },
                onRequestResign = {
                    viewModel.requestResign()
                },
                onConfirmResign = {
                    viewModel.confirmResign()
                },
                onCancelResign = {
                    viewModel.cancelResign()
                },
                onAcceptDraw = {
                    viewModel.acceptDraw()
                },
                onDeclineDraw = {
                    viewModel.declineDraw()
                },
                onToggleFlip = {
                    viewModel.toggleFlipBoard()
                },
                onOpenSettings = {
                    viewModel.navigateTo(Screen.SETTINGS)
                },
                onRematch = {
                    viewModel.restartGame()
                },
                onNewGame = {
                    viewModel.navigateTo(Screen.HOME)
                },
                onReturnHome = {
                    viewModel.navigateTo(Screen.HOME)
                }
            )
        }

        Screen.SETTINGS -> {
            SettingsScreen(
                state = state,
                onSoundChanged = { viewModel.setSoundEnabled(it) },
                onHapticsChanged = { viewModel.setHapticsEnabled(it) },
                onCoordinatesChanged = { viewModel.setShowCoordinates(it) },
                onLegalMovesChanged = { viewModel.setShowLegalMoves(it) },
                onMoveAnimationChanged = { viewModel.setMoveAnimation(it) },
                onConfirmResignChanged = { viewModel.setConfirmResignation(it) },
                onAutoFlipChanged = { viewModel.setAutoFlipBoard(it) },
                onThemeChanged = { viewModel.selectTheme(it) },
                onPieceStyleChanged = { viewModel.selectPieceStyle(it) },
                onBack = {
                    if (state.board.getMoveHistory().isNotEmpty() && !state.gameStatus.isGameOver) {
                        viewModel.navigateTo(Screen.GAME)
                    } else {
                        viewModel.navigateTo(Screen.HOME)
                    }
                }
            )
        }
    }
}
}
