package com.example.chess.ai

import com.example.chess.engine.ChessBoard
import com.example.chess.model.AiDifficulty
import com.example.chess.model.GameStatus
import com.example.chess.model.Move
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

object ChessEngineAi {

    // Piece-Square Tables (from White's perspective; mirrored for Black)
    private val PAWN_TABLE = intArrayOf(
        0,  0,  0,  0,  0,  0,  0,  0,
        50, 50, 50, 50, 50, 50, 50, 50,
        10, 10, 20, 30, 30, 20, 10, 10,
        5,  5, 10, 25, 25, 10,  5,  5,
        0,  0,  0, 20, 20,  0,  0,  0,
        5, -5,-10,  0,  0,-10, -5,  5,
        5, 10, 10,-20,-20, 10, 10,  5,
        0,  0,  0,  0,  0,  0,  0,  0
    )

    private val KNIGHT_TABLE = intArrayOf(
        -50,-40,-30,-30,-30,-30,-40,-50,
        -40,-20,  0,  0,  0,  0,-20,-40,
        -30,  0, 10, 15, 15, 10,  0,-30,
        -30,  5, 15, 20, 20, 15,  5,-30,
        -30,  0, 15, 20, 20, 15,  0,-30,
        -30,  5, 10, 15, 15, 10,  5,-30,
        -40,-20,  0,  5,  5,  0,-20,-40,
        -50,-40,-30,-30,-30,-30,-40,-50
    )

    private val BISHOP_TABLE = intArrayOf(
        -20,-10,-10,-10,-10,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5, 10, 10,  5,  0,-10,
        -10,  5,  5, 10, 10,  5,  5,-10,
        -10,  0, 10, 10, 10, 10,  0,-10,
        -10, 10, 10, 10, 10, 10, 10,-10,
        -10,  5,  0,  0,  0,  0,  5,-10,
        -20,-10,-10,-10,-10,-10,-10,-20
    )

    private val ROOK_TABLE = intArrayOf(
        0,  0,  0,  0,  0,  0,  0,  0,
        5, 10, 10, 10, 10, 10, 10,  5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        -5,  0,  0,  0,  0,  0,  0, -5,
        0,  0,  0,  5,  5,  0,  0,  0
    )

    private val QUEEN_TABLE = intArrayOf(
        -20,-10,-10, -5, -5,-10,-10,-20,
        -10,  0,  0,  0,  0,  0,  0,-10,
        -10,  0,  5,  5,  5,  5,  0,-10,
        -5,  0,  5,  5,  5,  5,  0, -5,
        0,  0,  5,  5,  5,  5,  0, -5,
        -10,  5,  5,  5,  5,  5,  0,-10,
        -10,  0,  5,  0,  0,  0,  0,-10,
        -20,-10,-10, -5, -5,-10,-10,-20
    )

    private val KING_MIDDLE_TABLE = intArrayOf(
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -30,-40,-40,-50,-50,-40,-40,-30,
        -20,-30,-30,-40,-40,-30,-30,-20,
        -10,-20,-20,-20,-20,-20,-20,-10,
        20, 20,  0,  0,  0,  0, 20, 20,
        20, 30, 10,  0,  0, 10, 30, 20
    )

    private const val CHECKMATE_SCORE = 100000
    private const val STALEMATE_SCORE = 0

    // Common opening book lines
    private val OPENING_BOOK = mapOf(
        // First move responses to 1. e4
        "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3" to listOf("e7e5", "c7c5", "e7e6", "c7c6"),
        // First move responses to 1. d4
        "rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq d3" to listOf("d7d5", "g8f6", "e7e6"),
        // 1. e4 e5 2. Nf3
        "rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq -" to listOf("b8c6", "g8f6"),
        // White opening moves
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -" to listOf("e2e4", "d2d4", "g1f3", "c2c4")
    )

    suspend fun findBestMove(
        board: ChessBoard,
        difficulty: AiDifficulty
    ): Move? = withContext(Dispatchers.Default) {
        val legalMoves = board.generateLegalMoves(board.activeColor)
        if (legalMoves.isEmpty()) return@withContext null

        // Add humanized realistic thinking pause (350ms - 850ms)
        val thinkingTime = when (difficulty.level) {
            1, 2 -> 350L + Random.nextLong(150)
            3, 4 -> 450L + Random.nextLong(200)
            5, 6 -> 550L + Random.nextLong(250)
            7, 8 -> 650L + Random.nextLong(300)
            else -> 750L + Random.nextLong(350)
        }
        delay(thinkingTime)

        // Check opening book for higher levels
        if (difficulty.level >= 4 && board.fullmoveNumber <= 3) {
            val fenPrefix = board.toFen().split(" ").take(4).joinToString(" ")
            val bookMoves = OPENING_BOOK.entries.find { it.key.startsWith(fenPrefix) }?.value
            if (!bookMoves.isNullOrEmpty()) {
                val chosenUci = bookMoves.random()
                val matchedMove = legalMoves.find { it.toUci().startsWith(chosenUci) }
                if (matchedMove != null) {
                    return@withContext matchedMove
                }
            }
        }

        // Ordered legal moves
        val orderedMoves = orderMoves(board, legalMoves)

        // Evaluate all top-level moves with alpha-beta search
        var bestMove = orderedMoves.first()
        var bestScore = -Int.MAX_VALUE
        val alpha = -Int.MAX_VALUE
        val beta = Int.MAX_VALUE

        val moveScores = mutableListOf<Pair<Move, Int>>()

        for (move in orderedMoves) {
            val nextBoard = board.copy()
            nextBoard.makeMove(move)

            val score = -alphaBeta(
                board = nextBoard,
                depth = difficulty.searchDepth - 1,
                alpha = -beta,
                beta = -alpha,
                isMaximizing = false,
                useQuiescence = difficulty.useQuiescence
            )

            moveScores.add(Pair(move, score))

            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
        }

        // Blunder simulation for lower difficulty levels
        if (difficulty.blunderProbability > 0f && Random.nextFloat() < difficulty.blunderProbability) {
            val acceptableScores = moveScores.filter {
                it.second >= bestScore - difficulty.maxBlunderPenalty
            }
            if (acceptableScores.isNotEmpty()) {
                return@withContext acceptableScores.random().first
            }
        }

        return@withContext bestMove
    }

    private fun alphaBeta(
        board: ChessBoard,
        depth: Int,
        alpha: Int,
        beta: Int,
        isMaximizing: Boolean,
        useQuiescence: Boolean
    ): Int {
        val status = board.getGameStatus()
        if (status == GameStatus.CHECKMATE) {
            return -CHECKMATE_SCORE - depth // Prefer faster mate
        }
        if (status == GameStatus.STALEMATE ||
            status == GameStatus.DRAW_INSUFFICIENT_MATERIAL ||
            status == GameStatus.DRAW_FIFTY_MOVES ||
            status == GameStatus.DRAW_THREEFOLD
        ) {
            return STALEMATE_SCORE
        }

        if (depth <= 0) {
            return if (useQuiescence) {
                quiescenceSearch(board, alpha, beta, 3)
            } else {
                evaluateBoard(board, board.activeColor)
            }
        }

        val legalMoves = board.generateLegalMoves(board.activeColor)
        if (legalMoves.isEmpty()) {
            return if (board.isInCheck(board.activeColor)) -CHECKMATE_SCORE - depth else STALEMATE_SCORE
        }

        val orderedMoves = orderMoves(board, legalMoves)
        var curAlpha = alpha

        for (move in orderedMoves) {
            val nextBoard = board.copy()
            nextBoard.makeMove(move)

            val score = -alphaBeta(
                board = nextBoard,
                depth = depth - 1,
                alpha = -beta,
                beta = -curAlpha,
                isMaximizing = !isMaximizing,
                useQuiescence = useQuiescence
            )

            if (score >= beta) {
                return beta // Beta cutoff
            }
            if (score > curAlpha) {
                curAlpha = score
            }
        }

        return curAlpha
    }

    private fun quiescenceSearch(board: ChessBoard, alpha: Int, beta: Int, qDepth: Int): Int {
        val standPat = evaluateBoard(board, board.activeColor)
        if (qDepth <= 0 || standPat >= beta) return beta

        var curAlpha = max(alpha, standPat)

        // Only search captures in quiescence
        val captureMoves = board.generateLegalMoves(board.activeColor).filter { it.isCapture }
        val orderedCaptures = orderMoves(board, captureMoves)

        for (move in orderedCaptures) {
            val nextBoard = board.copy()
            nextBoard.makeMove(move)

            val score = -quiescenceSearch(nextBoard, -beta, -curAlpha, qDepth - 1)

            if (score >= beta) return beta
            if (score > curAlpha) curAlpha = score
        }

        return curAlpha
    }

    private fun orderMoves(board: ChessBoard, moves: List<Move>): List<Move> {
        return moves.sortedByDescending { move ->
            var score = 0

            // 1. MVV-LVA for captures
            if (move.isCapture) {
                val victimVal = move.capturedPiece?.type?.value ?: 100
                val attackerVal = board.getPiece(move.from)?.type?.value ?: 100
                score += 1000 + (victimVal * 10 - attackerVal)
            }

            // 2. Promotion bonus
            if (move.promotion != null) {
                score += 800 + (move.promotion.value)
            }

            // 3. Castle bonus
            if (move.isCastling) {
                score += 300
            }

            // 4. Center control (e4, d4, e5, d5)
            val centerFiles = 3..4
            val centerRanks = 3..4
            if (move.to.file in centerFiles && move.to.rank in centerRanks) {
                score += 50
            }

            score
        }
    }

    fun evaluateBoard(board: ChessBoard, forColor: PieceColor): Int {
        var whiteScore = 0
        var blackScore = 0

        for (i in 0 until 64) {
            val piece = board.getPiece(Square.fromIndex(i)) ?: continue
            val rank = i / 8
            val file = i % 8

            // Material
            val material = piece.type.value

            // Positional table
            val posScore = getPieceSquareScore(piece.type, piece.color, file, rank)

            if (piece.color == PieceColor.WHITE) {
                whiteScore += material + posScore
            } else {
                blackScore += material + posScore
            }
        }

        // Center control
        for (f in 3..4) {
            for (r in 3..4) {
                val p = board.getPiece(f, r)
                if (p != null) {
                    if (p.color == PieceColor.WHITE) whiteScore += 15 else blackScore += 15
                }
            }
        }

        val perspectiveScore = if (forColor == PieceColor.WHITE) whiteScore - blackScore else blackScore - whiteScore
        return perspectiveScore
    }

    private fun getPieceSquareScore(type: PieceType, color: PieceColor, file: Int, rank: Int): Int {
        // Table indices are 0 (a8) to 63 (h1) in standard 8x8 arrays
        // Our rank is 0..7 (1st to 8th rank).
        // For White: rank 7 is row 0, rank 0 is row 7
        val r = if (color == PieceColor.WHITE) 7 - rank else rank
        val index = r * 8 + file

        if (index !in 0..63) return 0

        return when (type) {
            PieceType.PAWN -> PAWN_TABLE[index]
            PieceType.KNIGHT -> KNIGHT_TABLE[index]
            PieceType.BISHOP -> BISHOP_TABLE[index]
            PieceType.ROOK -> ROOK_TABLE[index]
            PieceType.QUEEN -> QUEEN_TABLE[index]
            PieceType.KING -> KING_MIDDLE_TABLE[index]
        }
    }
}
