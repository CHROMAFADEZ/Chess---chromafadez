package com.example.chess.data

import android.content.Context
import android.content.SharedPreferences

class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("chess_app_preferences", Context.MODE_PRIVATE)

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var hapticsEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTICS, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTICS, value).apply()

    var showCoordinates: Boolean
        get() = prefs.getBoolean(KEY_SHOW_COORDINATES, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_COORDINATES, value).apply()

    var showLegalMoves: Boolean
        get() = prefs.getBoolean(KEY_SHOW_LEGAL_MOVES, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_LEGAL_MOVES, value).apply()

    var moveAnimation: Boolean
        get() = prefs.getBoolean(KEY_MOVE_ANIMATION, true)
        set(value) = prefs.edit().putBoolean(KEY_MOVE_ANIMATION, value).apply()

    var confirmResignation: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_RESIGN, true)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRM_RESIGN, value).apply()

    var selectedThemeId: String
        get() = prefs.getString(KEY_THEME_ID, "classic") ?: "classic"
        set(value) = prefs.edit().putString(KEY_THEME_ID, value).apply()

    var pieceStyleId: String
        get() = prefs.getString(KEY_PIECE_STYLE_ID, "staunton") ?: "staunton"
        set(value) = prefs.edit().putString(KEY_PIECE_STYLE_ID, value).apply()

    var difficultyLevel: Int
        get() = prefs.getInt(KEY_DIFFICULTY, 5)
        set(value) = prefs.edit().putInt(KEY_DIFFICULTY, value).apply()

    var timeControlId: String
        get() = prefs.getString(KEY_TIME_CONTROL, "10m") ?: "10m"
        set(value) = prefs.edit().putString(KEY_TIME_CONTROL, value).apply()

    var autoFlipBoard: Boolean
        get() = prefs.getBoolean(KEY_AUTO_FLIP, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_FLIP, value).apply()

    var savedFen: String?
        get() = prefs.getString(KEY_SAVED_FEN, null)
        set(value) = prefs.edit().putString(KEY_SAVED_FEN, value).apply()

    var savedGameMode: String?
        get() = prefs.getString(KEY_SAVED_MODE, null)
        set(value) = prefs.edit().putString(KEY_SAVED_MODE, value).apply()

    companion object {
        private const val KEY_SOUND = "key_sound"
        private const val KEY_HAPTICS = "key_haptics"
        private const val KEY_SHOW_COORDINATES = "key_show_coordinates"
        private const val KEY_SHOW_LEGAL_MOVES = "key_show_legal_moves"
        private const val KEY_MOVE_ANIMATION = "key_move_animation"
        private const val KEY_CONFIRM_RESIGN = "key_confirm_resign"
        private const val KEY_THEME_ID = "key_theme_id"
        private const val KEY_PIECE_STYLE_ID = "key_piece_style_id"
        private const val KEY_DIFFICULTY = "key_difficulty"
        private const val KEY_TIME_CONTROL = "key_time_control"
        private const val KEY_AUTO_FLIP = "key_auto_flip"
        private const val KEY_SAVED_FEN = "key_saved_fen"
        private const val KEY_SAVED_MODE = "key_saved_mode"
    }
}
