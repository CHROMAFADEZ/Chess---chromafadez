package com.example.chess.engine

import com.example.chess.model.CastlingRights
import com.example.chess.model.GameStatus
import com.example.chess.model.Move
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlin.math.abs

class ChessBoard(
    private val squares: Array<Piece?> = Array(64) { null },
    var activeColor: PieceColor = PieceColor.WHITE,
    var castlingRights: CastlingRights = CastlingRights(),
    var enPassantTarget: Square? = null,
    var halfmoveClock: Int = 0,
    var fullmoveNumber: Int = 1
) {
    private val positionHistory = mutableListOf<String>()
    private val moveHistory = mutableListOf<Move>()
    private val capturedPiecesWhite = mutableListOf<Piece>()
    private val capturedPiecesBlack = mutableListOf<Piece>()

    init {
        recordPosition()
    }

    fun copy(): ChessBoard {
        val copy = ChessBoard(
            squares = squares.clone(),
            activeColor = activeColor,
            castlingRights = castlingRights.copy(),
            enPassantTarget = enPassantTarget,
            halfmoveClock = halfmoveClock,
            fullmoveNumber = fullmoveNumber
        )
        copy.positionHistory.clear()
        copy.positionHistory.addAll(this.positionHistory)
        copy.moveHistory.clear()
        copy.moveHistory.addAll(this.moveHistory)
        copy.capturedPiecesWhite.clear()
        copy.capturedPiecesWhite.addAll(this.capturedPiecesWhite)
        copy.capturedPiecesBlack.clear()
        copy.capturedPiecesBlack.addAll(this.capturedPiecesBlack)
        return copy
    }

    fun getPiece(square: Square): Piece? = squares[square.index]
    fun getPiece(file: Int, rank: Int): Piece? = squares[rank * 8 + file]

    fun setPiece(square: Square, piece: Piece?) {
        squares[square.index] = piece
    }

    fun getMoveHistory(): List<Move> = moveHistory.toList()
    fun getCapturedByWhite(): List<Piece> = capturedPiecesWhite.toList()
    fun getCapturedByBlack(): List<Piece> = capturedPiecesBlack.toList()

    fun getMaterialAdvantage(): Int {
        var whiteVal = 0
        var blackVal = 0
        for (i in 0 until 64) {
            val p = squares[i] ?: continue
            val v = when (p.type) {
                PieceType.PAWN -> 1
                PieceType.KNIGHT -> 3
                PieceType.BISHOP -> 3
                PieceType.ROOK -> 5
                PieceType.QUEEN -> 9
                PieceType.KING -> 0
            }
            if (p.color == PieceColor.WHITE) whiteVal += v else blackVal += v
        }
        return whiteVal - blackVal
    }

    fun resetToStartingPosition() {
        for (i in 0 until 64) squares[i] = null

        // White pieces
        squares[0] = Piece(PieceType.ROOK, PieceColor.WHITE)
        squares[1] = Piece(PieceType.KNIGHT, PieceColor.WHITE)
        squares[2] = Piece(PieceType.BISHOP, PieceColor.WHITE)
        squares[3] = Piece(PieceType.QUEEN, PieceColor.WHITE)
        squares[4] = Piece(PieceType.KING, PieceColor.WHITE)
        squares[5] = Piece(PieceType.BISHOP, PieceColor.WHITE)
        squares[6] = Piece(PieceType.KNIGHT, PieceColor.WHITE)
        squares[7] = Piece(PieceType.ROOK, PieceColor.WHITE)
        for (f in 0..7) squares[8 + f] = Piece(PieceType.PAWN, PieceColor.WHITE)

        // Black pieces
        for (f in 0..7) squares[48 + f] = Piece(PieceType.PAWN, PieceColor.BLACK)
        squares[56] = Piece(PieceType.ROOK, PieceColor.BLACK)
        squares[57] = Piece(PieceType.KNIGHT, PieceColor.BLACK)
        squares[58] = Piece(PieceType.BISHOP, PieceColor.BLACK)
        squares[59] = Piece(PieceType.QUEEN, PieceColor.BLACK)
        squares[60] = Piece(PieceType.KING, PieceColor.BLACK)
        squares[61] = Piece(PieceType.BISHOP, PieceColor.BLACK)
        squares[62] = Piece(PieceType.KNIGHT, PieceColor.BLACK)
        squares[63] = Piece(PieceType.ROOK, PieceColor.BLACK)

        activeColor = PieceColor.WHITE
        castlingRights = CastlingRights()
        enPassantTarget = null
        halfmoveClock = 0
        fullmoveNumber = 1
        positionHistory.clear()
        moveHistory.clear()
        capturedPiecesWhite.clear()
        capturedPiecesBlack.clear()
        recordPosition()
    }

    fun getKingSquare(color: PieceColor): Square? {
        for (i in 0 until 64) {
            val p = squares[i]
            if (p != null && p.color == color && p.type == PieceType.KING) {
                return Square.fromIndex(i)
            }
        }
        return null
    }

    fun isSquareAttacked(square: Square, byColor: PieceColor): Boolean {
        val targetIdx = square.index
        val targetFile = square.file
        val targetRank = square.rank

        // 1. Pawn attacks
        val pawnDir = if (byColor == PieceColor.WHITE) 1 else -1
        val pawnRank = targetRank - pawnDir
        if (pawnRank in 0..7) {
            if (targetFile - 1 >= 0) {
                val p = getPiece(targetFile - 1, pawnRank)
                if (p != null && p.color == byColor && p.type == PieceType.PAWN) return true
            }
            if (targetFile + 1 <= 7) {
                val p = getPiece(targetFile + 1, pawnRank)
                if (p != null && p.color == byColor && p.type == PieceType.PAWN) return true
            }
        }

        // 2. Knight attacks
        val knightOffsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((df, dr) in knightOffsets) {
            val f = targetFile + df
            val r = targetRank + dr
            if (f in 0..7 && r in 0..7) {
                val p = getPiece(f, r)
                if (p != null && p.color == byColor && p.type == PieceType.KNIGHT) return true
            }
        }

        // 3. King attacks (adjacent squares)
        val kingOffsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((df, dr) in kingOffsets) {
            val f = targetFile + df
            val r = targetRank + dr
            if (f in 0..7 && r in 0..7) {
                val p = getPiece(f, r)
                if (p != null && p.color == byColor && p.type == PieceType.KING) return true
            }
        }

        // 4. Orthogonal attacks (Rook, Queen)
        val orthoDirs = arrayOf(Pair(1, 0), Pair(-1, 0), Pair(0, 1), Pair(0, -1))
        for ((df, dr) in orthoDirs) {
            var f = targetFile + df
            var r = targetRank + dr
            while (f in 0..7 && r in 0..7) {
                val p = getPiece(f, r)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                f += df
                r += dr
            }
        }

        // 5. Diagonal attacks (Bishop, Queen)
        val diagDirs = arrayOf(Pair(1, 1), Pair(1, -1), Pair(-1, 1), Pair(-1, -1))
        for ((df, dr) in diagDirs) {
            var f = targetFile + df
            var r = targetRank + dr
            while (f in 0..7 && r in 0..7) {
                val p = getPiece(f, r)
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                f += df
                r += dr
            }
        }

        return false
    }

    fun isInCheck(color: PieceColor = activeColor): Boolean {
        val kingSquare = getKingSquare(color) ?: return false
        return isSquareAttacked(kingSquare, color.opponent())
    }

    fun generateLegalMoves(color: PieceColor = activeColor): List<Move> {
        val pseudoMoves = generatePseudoLegalMoves(color)
        val legalMoves = mutableListOf<Move>()

        for (m in pseudoMoves) {
            val testBoard = copy()
            testBoard.executeMoveInternal(m)
            if (!testBoard.isInCheck(color)) {
                // Enrich with SAN
                val enrichedMove = enrichMoveWithSan(m, pseudoMoves)
                legalMoves.add(enrichedMove)
            }
        }
        return legalMoves
    }

    fun getLegalMovesForSquare(square: Square): List<Move> {
        val piece = getPiece(square) ?: return emptyList()
        if (piece.color != activeColor) return emptyList()
        return generateLegalMoves(activeColor).filter { it.from == square }
    }

    private fun generatePseudoLegalMoves(color: PieceColor): List<Move> {
        val moves = mutableListOf<Move>()
        for (i in 0 until 64) {
            val p = squares[i] ?: continue
            if (p.color != color) continue
            val from = Square.fromIndex(i)

            when (p.type) {
                PieceType.PAWN -> generatePawnMoves(from, color, moves)
                PieceType.KNIGHT -> generateKnightMoves(from, color, moves)
                PieceType.BISHOP -> generateBishopMoves(from, color, moves)
                PieceType.ROOK -> generateRookMoves(from, color, moves)
                PieceType.QUEEN -> generateQueenMoves(from, color, moves)
                PieceType.KING -> generateKingMoves(from, color, moves)
            }
        }
        return moves
    }

    private fun generatePawnMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val forwardDir = if (color == PieceColor.WHITE) 1 else -1
        val startRank = if (color == PieceColor.WHITE) 1 else 6
        val promoRank = if (color == PieceColor.WHITE) 7 else 0

        val nextRank = from.rank + forwardDir
        if (nextRank in 0..7) {
            // 1 square forward
            if (getPiece(from.file, nextRank) == null) {
                val to = Square(from.file, nextRank)
                if (nextRank == promoRank) {
                    addPromotionMoves(from, to, null, moves)
                } else {
                    moves.add(Move(from, to))
                }

                // 2 squares forward from start rank
                val doubleRank = from.rank + 2 * forwardDir
                if (from.rank == startRank && doubleRank in 0..7 && getPiece(from.file, doubleRank) == null) {
                    moves.add(Move(from, Square(from.file, doubleRank)))
                }
            }

            // Diagonal captures
            for (df in arrayOf(-1, 1)) {
                val capFile = from.file + df
                if (capFile in 0..7) {
                    val targetSquare = Square(capFile, nextRank)
                    val targetPiece = getPiece(targetSquare)
                    if (targetPiece != null && targetPiece.color != color) {
                        if (nextRank == promoRank) {
                            addPromotionMoves(from, targetSquare, targetPiece, moves)
                        } else {
                            moves.add(Move(from, targetSquare, capturedPiece = targetPiece))
                        }
                    } else if (enPassantTarget != null && enPassantTarget == targetSquare) {
                        val epCapturedPiece = getPiece(capFile, from.rank)
                        moves.add(Move(from, targetSquare, isEnPassant = true, capturedPiece = epCapturedPiece))
                    }
                }
            }
        }
    }

    private fun addPromotionMoves(from: Square, to: Square, captured: Piece?, moves: MutableList<Move>) {
        moves.add(Move(from, to, promotion = PieceType.QUEEN, capturedPiece = captured))
        moves.add(Move(from, to, promotion = PieceType.ROOK, capturedPiece = captured))
        moves.add(Move(from, to, promotion = PieceType.BISHOP, capturedPiece = captured))
        moves.add(Move(from, to, promotion = PieceType.KNIGHT, capturedPiece = captured))
    }

    private fun generateKnightMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val offsets = arrayOf(
            Pair(-2, -1), Pair(-2, 1), Pair(-1, -2), Pair(-1, 2),
            Pair(1, -2), Pair(1, 2), Pair(2, -1), Pair(2, 1)
        )
        for ((df, dr) in offsets) {
            val f = from.file + df
            val r = from.rank + dr
            if (f in 0..7 && r in 0..7) {
                val targetSquare = Square(f, r)
                val targetPiece = getPiece(targetSquare)
                if (targetPiece == null) {
                    moves.add(Move(from, targetSquare))
                } else if (targetPiece.color != color) {
                    moves.add(Move(from, targetSquare, capturedPiece = targetPiece))
                }
            }
        }
    }

    private fun generateBishopMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val dirs = arrayOf(Pair(1, 1), Pair(1, -1), Pair(-1, 1), Pair(-1, -1))
        generateRayMoves(from, color, dirs, moves)
    }

    private fun generateRookMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val dirs = arrayOf(Pair(1, 0), Pair(-1, 0), Pair(0, 1), Pair(0, -1))
        generateRayMoves(from, color, dirs, moves)
    }

    private fun generateQueenMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val dirs = arrayOf(
            Pair(1, 0), Pair(-1, 0), Pair(0, 1), Pair(0, -1),
            Pair(1, 1), Pair(1, -1), Pair(-1, 1), Pair(-1, -1)
        )
        generateRayMoves(from, color, dirs, moves)
    }

    private fun generateRayMoves(from: Square, color: PieceColor, dirs: Array<Pair<Int, Int>>, moves: MutableList<Move>) {
        for ((df, dr) in dirs) {
            var f = from.file + df
            var r = from.rank + dr
            while (f in 0..7 && r in 0..7) {
                val targetSquare = Square(f, r)
                val targetPiece = getPiece(targetSquare)
                if (targetPiece == null) {
                    moves.add(Move(from, targetSquare))
                } else {
                    if (targetPiece.color != color) {
                        moves.add(Move(from, targetSquare, capturedPiece = targetPiece))
                    }
                    break
                }
                f += df
                r += dr
            }
        }
    }

    private fun generateKingMoves(from: Square, color: PieceColor, moves: MutableList<Move>) {
        val offsets = arrayOf(
            Pair(-1, -1), Pair(-1, 0), Pair(-1, 1),
            Pair(0, -1), Pair(0, 1),
            Pair(1, -1), Pair(1, 0), Pair(1, 1)
        )
        for ((df, dr) in offsets) {
            val f = from.file + df
            val r = from.rank + dr
            if (f in 0..7 && r in 0..7) {
                val targetSquare = Square(f, r)
                val targetPiece = getPiece(targetSquare)
                if (targetPiece == null) {
                    moves.add(Move(from, targetSquare))
                } else if (targetPiece.color != color) {
                    moves.add(Move(from, targetSquare, capturedPiece = targetPiece))
                }
            }
        }

        // Castling
        val enemyColor = color.opponent()
        val rank = if (color == PieceColor.WHITE) 0 else 7
        val kingSquare = Square(4, rank)

        if (from == kingSquare && !isInCheck(color)) {
            // King-side castling (e -> g, rooks on h)
            val canKingSide = if (color == PieceColor.WHITE) castlingRights.whiteKingSide else castlingRights.blackKingSide
            if (canKingSide) {
                val f1 = Square(5, rank)
                val g1 = Square(6, rank)
                val h1 = Square(7, rank)
                val rook = getPiece(h1)
                if (rook != null && rook.type == PieceType.ROOK && rook.color == color &&
                    getPiece(f1) == null && getPiece(g1) == null &&
                    !isSquareAttacked(f1, enemyColor) && !isSquareAttacked(g1, enemyColor)
                ) {
                    moves.add(Move(from, g1, isCastling = true))
                }
            }

            // Queen-side castling (e -> c, rooks on a)
            val canQueenSide = if (color == PieceColor.WHITE) castlingRights.whiteQueenSide else castlingRights.blackQueenSide
            if (canQueenSide) {
                val d1 = Square(3, rank)
                val c1 = Square(2, rank)
                val b1 = Square(1, rank)
                val a1 = Square(0, rank)
                val rook = getPiece(a1)
                if (rook != null && rook.type == PieceType.ROOK && rook.color == color &&
                    getPiece(d1) == null && getPiece(c1) == null && getPiece(b1) == null &&
                    !isSquareAttacked(d1, enemyColor) && !isSquareAttacked(c1, enemyColor)
                ) {
                    moves.add(Move(from, c1, isCastling = true))
                }
            }
        }
    }

    private fun enrichMoveWithSan(move: Move, allPseudoMoves: List<Move>): Move {
        val piece = getPiece(move.from) ?: return move
        if (move.isCastling) {
            val san = if (move.to.file == 6) "O-O" else "O-O-O"
            return move.copy(san = san)
        }

        val sb = StringBuilder()
        if (piece.type == PieceType.PAWN) {
            if (move.isCapture) {
                sb.append('a' + move.from.file)
                sb.append('x')
            }
            sb.append(move.to.algebraic)
            if (move.promotion != null) {
                sb.append('=')
                sb.append(move.promotion.notationLetter)
            }
        } else {
            sb.append(piece.type.notationLetter)

            // Disambiguation
            val conflicts = allPseudoMoves.filter {
                it.from != move.from && it.to == move.to && getPiece(it.from)?.type == piece.type && getPiece(it.from)?.color == piece.color
            }
            if (conflicts.isNotEmpty()) {
                val sameFile = conflicts.any { it.from.file == move.from.file }
                val sameRank = conflicts.any { it.from.rank == move.from.rank }
                if (!sameFile) {
                    sb.append('a' + move.from.file)
                } else if (!sameRank) {
                    sb.append(move.from.rank + 1)
                } else {
                    sb.append(move.from.algebraic)
                }
            }

            if (move.isCapture) {
                sb.append('x')
            }
            sb.append(move.to.algebraic)
        }

        // Test check / checkmate on test board
        val testBoard = copy()
        testBoard.executeMoveInternal(move)
        val opponentInCheck = testBoard.isInCheck(piece.color.opponent())
        if (opponentInCheck) {
            val opponentMoves = testBoard.generateLegalMoves(piece.color.opponent())
            if (opponentMoves.isEmpty()) {
                sb.append('#')
            } else {
                sb.append('+')
            }
        }

        return move.copy(san = sb.toString())
    }

    fun makeMove(move: Move): Boolean {
        val legalMoves = generateLegalMoves(activeColor)
        val matchedMove = legalMoves.find {
            it.from == move.from && it.to == move.to && it.promotion == move.promotion
        } ?: return false

        executeMoveInternal(matchedMove)
        recordPosition()
        return true
    }

    private fun executeMoveInternal(move: Move) {
        val piece = getPiece(move.from) ?: return
        val captured = getPiece(move.to)

        // Track captured pieces
        if (move.isEnPassant) {
            val epPawnSquare = Square(move.to.file, move.from.rank)
            val epPawn = getPiece(epPawnSquare)
            if (epPawn != null) {
                if (activeColor == PieceColor.WHITE) capturedPiecesWhite.add(epPawn)
                else capturedPiecesBlack.add(epPawn)
                setPiece(epPawnSquare, null)
            }
        } else if (captured != null) {
            if (activeColor == PieceColor.WHITE) capturedPiecesWhite.add(captured)
            else capturedPiecesBlack.add(captured)
        }

        // Update halfmove clock (reset on pawn advance or capture)
        if (piece.type == PieceType.PAWN || move.isCapture) {
            halfmoveClock = 0
        } else {
            halfmoveClock++
        }

        // Update castling rights
        var newCastling = castlingRights
        if (piece.type == PieceType.KING) {
            newCastling = if (piece.color == PieceColor.WHITE) {
                newCastling.copy(whiteKingSide = false, whiteQueenSide = false)
            } else {
                newCastling.copy(blackKingSide = false, blackQueenSide = false)
            }
        }
        if (piece.type == PieceType.ROOK) {
            if (move.from.rank == 0 && move.from.file == 0) newCastling = newCastling.copy(whiteQueenSide = false)
            if (move.from.rank == 0 && move.from.file == 7) newCastling = newCastling.copy(whiteKingSide = false)
            if (move.from.rank == 7 && move.from.file == 0) newCastling = newCastling.copy(blackQueenSide = false)
            if (move.from.rank == 7 && move.from.file == 7) newCastling = newCastling.copy(blackKingSide = false)
        }
        if (captured?.type == PieceType.ROOK) {
            if (move.to.rank == 0 && move.to.file == 0) newCastling = newCastling.copy(whiteQueenSide = false)
            if (move.to.rank == 0 && move.to.file == 7) newCastling = newCastling.copy(whiteKingSide = false)
            if (move.to.rank == 7 && move.to.file == 0) newCastling = newCastling.copy(blackQueenSide = false)
            if (move.to.rank == 7 && move.to.file == 7) newCastling = newCastling.copy(blackKingSide = false)
        }
        castlingRights = newCastling

        // Castling rook move
        if (move.isCastling) {
            val rank = move.from.rank
            if (move.to.file == 6) { // King-side
                setPiece(Square(5, rank), getPiece(Square(7, rank)))
                setPiece(Square(7, rank), null)
            } else if (move.to.file == 2) { // Queen-side
                setPiece(Square(3, rank), getPiece(Square(0, rank)))
                setPiece(Square(0, rank), null)
            }
        }

        // En passant target calculation
        if (piece.type == PieceType.PAWN && abs(move.to.rank - move.from.rank) == 2) {
            val epRank = (move.from.rank + move.to.rank) / 2
            enPassantTarget = Square(move.from.file, epRank)
        } else {
            enPassantTarget = null
        }

        // Place moved piece / promotion
        val placedPiece = if (move.promotion != null) {
            Piece(move.promotion, piece.color)
        } else {
            piece
        }
        setPiece(move.to, placedPiece)
        setPiece(move.from, null)

        // Turn toggle & fullmove number
        if (activeColor == PieceColor.BLACK) {
            fullmoveNumber++
        }
        activeColor = activeColor.opponent()

        moveHistory.add(move)
    }

    private fun recordPosition() {
        val signature = getPositionSignature()
        positionHistory.add(signature)
    }

    private fun getPositionSignature(): String {
        val sb = StringBuilder()
        for (i in 0 until 64) {
            val p = squares[i]
            sb.append(p?.fenChar ?: '.')
        }
        sb.append(' ')
        sb.append(if (activeColor == PieceColor.WHITE) 'w' else 'b')
        sb.append(' ')
        sb.append(castlingRights.toFen())
        sb.append(' ')
        sb.append(enPassantTarget?.algebraic ?: "-")
        return sb.toString()
    }

    fun getGameStatus(): GameStatus {
        val legalMoves = generateLegalMoves(activeColor)
        val inCheck = isInCheck(activeColor)

        if (legalMoves.isEmpty()) {
            return if (inCheck) GameStatus.CHECKMATE else GameStatus.STALEMATE
        }

        if (halfmoveClock >= 100) {
            return GameStatus.DRAW_FIFTY_MOVES
        }

        if (isThreefoldRepetition()) {
            return GameStatus.DRAW_THREEFOLD
        }

        if (isInsufficientMaterial()) {
            return GameStatus.DRAW_INSUFFICIENT_MATERIAL
        }

        return if (inCheck) GameStatus.CHECK else GameStatus.ACTIVE
    }

    private fun isThreefoldRepetition(): Boolean {
        val current = getPositionSignature()
        var count = 0
        for (pos in positionHistory) {
            if (pos == current) count++
        }
        return count >= 3
    }

    private fun isInsufficientMaterial(): Boolean {
        var whiteKnights = 0
        var whiteBishops = 0
        var whiteBishopLight = false
        var whiteBishopDark = false

        var blackKnights = 0
        var blackBishops = 0
        var blackBishopLight = false
        var blackBishopDark = false

        for (i in 0 until 64) {
            val p = squares[i] ?: continue
            when (p.type) {
                PieceType.PAWN, PieceType.ROOK, PieceType.QUEEN -> return false
                PieceType.KING -> {}
                PieceType.KNIGHT -> {
                    if (p.color == PieceColor.WHITE) whiteKnights++ else blackKnights++
                }
                PieceType.BISHOP -> {
                    val sq = Square.fromIndex(i)
                    if (p.color == PieceColor.WHITE) {
                        whiteBishops++
                        if (sq.isLightSquare) whiteBishopLight = true else whiteBishopDark = true
                    } else {
                        blackBishops++
                        if (sq.isLightSquare) blackBishopLight = true else blackBishopDark = true
                    }
                }
            }
        }

        val totalWhiteMinors = whiteKnights + whiteBishops
        val totalBlackMinors = blackKnights + blackBishops

        // K vs K
        if (totalWhiteMinors == 0 && totalBlackMinors == 0) return true

        // K+B vs K or K+N vs K
        if ((totalWhiteMinors == 1 && totalBlackMinors == 0) || (totalWhiteMinors == 0 && totalBlackMinors == 1)) return true

        // K+B vs K+B with same square color
        if (whiteBishops == 1 && whiteKnights == 0 && blackBishops == 1 && blackKnights == 0) {
            if ((whiteBishopLight && blackBishopLight) || (whiteBishopDark && blackBishopDark)) {
                return true
            }
        }

        return false
    }

    fun toFen(): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var emptyCount = 0
            for (f in 0..7) {
                val p = getPiece(f, r)
                if (p == null) {
                    emptyCount++
                } else {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    sb.append(p.fenChar)
                }
            }
            if (emptyCount > 0) sb.append(emptyCount)
            if (r > 0) sb.append('/')
        }
        sb.append(' ')
        sb.append(if (activeColor == PieceColor.WHITE) 'w' else 'b')
        sb.append(' ')
        sb.append(castlingRights.toFen())
        sb.append(' ')
        sb.append(enPassantTarget?.algebraic ?: "-")
        sb.append(' ')
        sb.append(halfmoveClock)
        sb.append(' ')
        sb.append(fullmoveNumber)
        return sb.toString()
    }

    companion object {
        fun createStartingBoard(): ChessBoard {
            val board = ChessBoard()
            board.resetToStartingPosition()
            return board
        }
    }
}
