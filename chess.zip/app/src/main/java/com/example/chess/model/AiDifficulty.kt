package com.example.chess.model

data class AiDifficulty(
    val level: Int,
    val name: String,
    val elo: Int,
    val searchDepth: Int,
    val blunderProbability: Float, // Probability of making a sub-optimal move
    val maxBlunderPenalty: Int,    // Max centipawn penalty on blunder
    val useQuiescence: Boolean,
    val description: String
) {
    val formattedNumber: String
        get() = String.format("%02d", level)

    companion object {
        val LEVEL_1 = AiDifficulty(
            level = 1,
            name = "Beginner",
            elo = 600,
            searchDepth = 1,
            blunderProbability = 0.40f,
            maxBlunderPenalty = 300,
            useQuiescence = false,
            description = "Learning rules and fundamental captures"
        )
        val LEVEL_2 = AiDifficulty(
            level = 2,
            name = "Easy",
            elo = 800,
            searchDepth = 1,
            blunderProbability = 0.28f,
            maxBlunderPenalty = 220,
            useQuiescence = false,
            description = "Understands basic piece exchanges"
        )
        val LEVEL_3 = AiDifficulty(
            level = 3,
            name = "Casual",
            elo = 1000,
            searchDepth = 2,
            blunderProbability = 0.20f,
            maxBlunderPenalty = 150,
            useQuiescence = false,
            description = "Solid opening pawn moves and developing pieces"
        )
        val LEVEL_4 = AiDifficulty(
            level = 4,
            name = "Moderate",
            elo = 1200,
            searchDepth = 2,
            blunderProbability = 0.12f,
            maxBlunderPenalty = 100,
            useQuiescence = false,
            description = "Develops pieces actively and controls center"
        )
        val LEVEL_5 = AiDifficulty(
            level = 5,
            name = "Intermediate",
            elo = 1400,
            searchDepth = 3,
            blunderProbability = 0.06f,
            maxBlunderPenalty = 70,
            useQuiescence = false,
            description = "Avoids 1-move blunders, calculates tactical threats"
        )
        val LEVEL_6 = AiDifficulty(
            level = 6,
            name = "Advanced",
            elo = 1600,
            searchDepth = 3,
            blunderProbability = 0.02f,
            maxBlunderPenalty = 40,
            useQuiescence = true,
            description = "Sound positional sense, checks capture chains"
        )
        val LEVEL_7 = AiDifficulty(
            level = 7,
            name = "Expert",
            elo = 1800,
            searchDepth = 4,
            blunderProbability = 0.0f,
            maxBlunderPenalty = 0,
            useQuiescence = true,
            description = "High tactical awareness and king protection"
        )
        val LEVEL_8 = AiDifficulty(
            level = 8,
            name = "Master",
            elo = 2000,
            searchDepth = 4,
            blunderProbability = 0.0f,
            maxBlunderPenalty = 0,
            useQuiescence = true,
            description = "Deep search with aggressive pawn structure evaluation"
        )
        val LEVEL_9 = AiDifficulty(
            level = 9,
            name = "Grandmaster",
            elo = 2200,
            searchDepth = 5,
            blunderProbability = 0.0f,
            maxBlunderPenalty = 0,
            useQuiescence = true,
            description = "Full alpha-beta with opening repertoire and endgame mastery"
        )
        val LEVEL_10 = AiDifficulty(
            level = 10,
            name = "Legend",
            elo = 2400,
            searchDepth = 5,
            blunderProbability = 0.0f,
            maxBlunderPenalty = 0,
            useQuiescence = true,
            description = "Maximum tactical depth and relentless precision"
        )

        val ALL = listOf(
            LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5,
            LEVEL_6, LEVEL_7, LEVEL_8, LEVEL_9, LEVEL_10
        )

        fun fromLevel(level: Int): AiDifficulty {
            return ALL.find { it.level == level } ?: LEVEL_5
        }
    }
}
