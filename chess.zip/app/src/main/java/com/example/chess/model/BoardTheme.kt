package com.example.chess.model

import androidx.compose.ui.graphics.Color

data class BoardTheme(
    val id: String,
    val name: String,
    val lightSquare: Color,
    val darkSquare: Color,
    val selectedSquare: Color,
    val lastMoveLight: Color,
    val lastMoveDark: Color,
    val legalMoveDot: Color,
    val checkSquare: Color,
    val boardBorder: Color,
    val coordinateTextLight: Color,
    val coordinateTextDark: Color
) {
    companion object {
        val CLASSIC = BoardTheme(
            id = "classic",
            name = "Classic",
            lightSquare = Color(0xFFF0D9B5),
            darkSquare = Color(0xFFB58863),
            selectedSquare = Color(0x99C4A44D),
            lastMoveLight = Color(0x66CDD26A),
            lastMoveDark = Color(0x88AAA23A),
            legalMoveDot = Color(0x662C2621),
            checkSquare = Color(0xAAEB4D4B),
            boardBorder = Color(0xFF8A6240),
            coordinateTextLight = Color(0xFFB58863),
            coordinateTextDark = Color(0xFFF0D9B5)
        )

        val TOURNAMENT = BoardTheme(
            id = "tournament",
            name = "Tournament",
            lightSquare = Color(0xFFEEEED2),
            darkSquare = Color(0xFF769656),
            selectedSquare = Color(0x99BACA44),
            lastMoveLight = Color(0x77F7F783),
            lastMoveDark = Color(0x99BAC54B),
            legalMoveDot = Color(0x66334422),
            checkSquare = Color(0xAAEB4D4B),
            boardBorder = Color(0xFF5A7540),
            coordinateTextLight = Color(0xFF769656),
            coordinateTextDark = Color(0xFFEEEED2)
        )

        val IVORY = BoardTheme(
            id = "ivory",
            name = "Ivory",
            lightSquare = Color(0xFFFAF0E6),
            darkSquare = Color(0xFFC4B89D),
            selectedSquare = Color(0x99D5C48A),
            lastMoveLight = Color(0x66E6DBB5),
            lastMoveDark = Color(0x88BDB18F),
            legalMoveDot = Color(0x664A4035),
            checkSquare = Color(0xAAD9534F),
            boardBorder = Color(0xFFA89978),
            coordinateTextLight = Color(0xFFC4B89D),
            coordinateTextDark = Color(0xFFFAF0E6)
        )

        val NATURAL_WOOD = BoardTheme(
            id = "wood",
            name = "Natural Wood",
            lightSquare = Color(0xFFEAD8B8),
            darkSquare = Color(0xFFA67C52),
            selectedSquare = Color(0x99C29A64),
            lastMoveLight = Color(0x66DDC89A),
            lastMoveDark = Color(0x88986B3E),
            legalMoveDot = Color(0x663B291A),
            checkSquare = Color(0xAAEB4D4B),
            boardBorder = Color(0xFF7D5832),
            coordinateTextLight = Color(0xFFA67C52),
            coordinateTextDark = Color(0xFFEAD8B8)
        )

        val PAPER = BoardTheme(
            id = "paper",
            name = "Paper",
            lightSquare = Color(0xFFF7F5EE),
            darkSquare = Color(0xFFB8C0C8),
            selectedSquare = Color(0x99A0B8C8),
            lastMoveLight = Color(0x66DCE4EC),
            lastMoveDark = Color(0x889FAEB8),
            legalMoveDot = Color(0x663C444C),
            checkSquare = Color(0xAAEB4D4B),
            boardBorder = Color(0xFF909AA4),
            coordinateTextLight = Color(0xFFB8C0C8),
            coordinateTextDark = Color(0xFFF7F5EE)
        )

        val ALL = listOf(CLASSIC, TOURNAMENT, IVORY, NATURAL_WOOD, PAPER)

        fun fromId(id: String?): BoardTheme {
            return ALL.find { it.id == id } ?: CLASSIC
        }
    }
}
