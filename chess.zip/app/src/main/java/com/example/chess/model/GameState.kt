package com.example.chess.model

enum class GameStatus {
    ACTIVE,
    CHECK,
    CHECKMATE,
    STALEMATE,
    DRAW_INSUFFICIENT_MATERIAL,
    DRAW_FIFTY_MOVES,
    DRAW_THREEFOLD,
    DRAW_AGREED,
    RESIGNED,
    TIMEOUT;

    val isGameOver: Boolean
        get() = this != ACTIVE && this != CHECK
}

enum class GameMode {
    VS_AI,
    LOCAL_FRIEND
}
