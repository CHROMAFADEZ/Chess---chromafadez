package com.example.chess.model

data class Move(
    val from: Square,
    val to: Square,
    val promotion: PieceType? = null,
    val isEnPassant: Boolean = false,
    val isCastling: Boolean = false,
    val capturedPiece: Piece? = null,
    val san: String = ""
) {
    val isCapture: Boolean
        get() = capturedPiece != null || isEnPassant

    fun toUci(): String {
        val promo = when (promotion) {
            PieceType.QUEEN -> "q"
            PieceType.ROOK -> "r"
            PieceType.BISHOP -> "b"
            PieceType.KNIGHT -> "n"
            else -> ""
        }
        return "${from.algebraic}${to.algebraic}$promo"
    }
}
