package com.example.chess.model

enum class PieceStyle(val id: String, val displayName: String, val description: String) {
    STAUNTON("staunton", "Staunton", "Traditional sculpted wooden tournament silhouettes"),
    CLASSIC("classic", "Classic", "High-contrast balanced tournament outlines"),
    MINIMAL("minimal", "Minimal", "Refined, understated geometric profiles");

    companion object {
        fun fromId(id: String?): PieceStyle {
            return entries.find { it.id == id } ?: STAUNTON
        }
    }
}
