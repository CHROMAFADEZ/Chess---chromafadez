package com.example.chess.model

data class Square(
    val file: Int, // 0..7 representing 'a'..'h'
    val rank: Int  // 0..7 representing 1..8
) {
    init {
        require(file in 0..7 && rank in 0..7) { "Invalid square coordinates: file=$file, rank=$rank" }
    }

    val index: Int
        get() = rank * 8 + file

    val isLightSquare: Boolean
        get() = (file + rank) % 2 != 0

    val algebraic: String
        get() = "${('a' + file)}${rank + 1}"

    companion object {
        fun fromIndex(index: Int): Square {
            require(index in 0..63) { "Invalid square index: $index" }
            return Square(file = index % 8, rank = index / 8)
        }

        fun fromAlgebraic(notation: String): Square? {
            if (notation.length != 2) return null
            val f = notation[0].lowercaseChar() - 'a'
            val r = notation[1].digitToIntOrNull()?.minus(1) ?: return null
            if (f !in 0..7 || r !in 0..7) return null
            return Square(file = f, rank = r)
        }
    }
}
