package com.example.chess.model

data class TimeControl(
    val id: String,
    val name: String,
    val totalSeconds: Int, // 0 for unlimited
    val incrementSeconds: Int = 0
) {
    val isUnlimited: Boolean
        get() = totalSeconds <= 0

    companion object {
        val ONE_MIN = TimeControl("1m", "1 min", 60)
        val THREE_MIN = TimeControl("3m", "3 min", 180)
        val FIVE_MIN = TimeControl("5m", "5 min", 300)
        val TEN_MIN = TimeControl("10m", "10 min", 600)
        val FIFTEEN_MIN = TimeControl("15m", "15 min", 900)
        val THIRTY_MIN = TimeControl("30m", "30 min", 1800)
        val UNLIMITED = TimeControl("unlimited", "Unlimited", 0)

        val ALL = listOf(
            ONE_MIN,
            THREE_MIN,
            FIVE_MIN,
            TEN_MIN,
            FIFTEEN_MIN,
            THIRTY_MIN,
            UNLIMITED
        )

        fun fromId(id: String?): TimeControl {
            return ALL.find { it.id == id } ?: TEN_MIN
        }
    }
}
