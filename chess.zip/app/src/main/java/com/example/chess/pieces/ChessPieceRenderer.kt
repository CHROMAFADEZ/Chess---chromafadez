package com.example.chess.pieces

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType

import com.example.chess.model.PieceStyle

object ChessPieceRenderer {

    // Natural Staunton colors
    val WhiteFill = Color(0xFFFCFBF8)
    val WhiteOutline = Color(0xFF262421)
    val WhiteDetail = Color(0xFF3E3B36)

    val BlackFill = Color(0xFF242220)
    val BlackOutline = Color(0xFF141312)
    val BlackDetail = Color(0xFFECE7DE)

    @Composable
    fun RenderPiece(
        piece: Piece,
        modifier: Modifier = Modifier,
        style: PieceStyle = PieceStyle.STAUNTON
    ) {
        Box(modifier = modifier) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val isWhite = piece.color == PieceColor.WHITE
                val fillColor = if (isWhite) WhiteFill else BlackFill
                val strokeColor = if (isWhite) WhiteOutline else BlackDetail
                val outlineColor = if (isWhite) WhiteOutline else BlackOutline

                when (style) {
                    PieceStyle.STAUNTON -> {
                        when (piece.type) {
                            PieceType.PAWN -> drawStauntonPawn(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KNIGHT -> drawStauntonKnight(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.BISHOP -> drawStauntonBishop(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.ROOK -> drawStauntonRook(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.QUEEN -> drawStauntonQueen(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KING -> drawStauntonKing(fillColor, strokeColor, outlineColor, isWhite)
                        }
                    }
                    PieceStyle.CLASSIC -> {
                        when (piece.type) {
                            PieceType.PAWN -> drawClassicPawn(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KNIGHT -> drawClassicKnight(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.BISHOP -> drawClassicBishop(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.ROOK -> drawClassicRook(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.QUEEN -> drawClassicQueen(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KING -> drawClassicKing(fillColor, strokeColor, outlineColor, isWhite)
                        }
                    }
                    PieceStyle.MINIMAL -> {
                        when (piece.type) {
                            PieceType.PAWN -> drawMinimalPawn(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KNIGHT -> drawMinimalKnight(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.BISHOP -> drawMinimalBishop(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.ROOK -> drawMinimalRook(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.QUEEN -> drawMinimalQueen(fillColor, strokeColor, outlineColor, isWhite)
                            PieceType.KING -> drawMinimalKing(fillColor, strokeColor, outlineColor, isWhite)
                        }
                    }
                }
            }
        }
    }

    private fun DrawScope.drawStauntonPawn(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Head (sphere)
        val headRadius = w * 0.16f
        val headCenterY = h * 0.32f
        drawCircle(color = fill, radius = headRadius, center = Offset(cx, headCenterY))
        drawCircle(color = outline, radius = headRadius, center = Offset(cx, headCenterY), style = Stroke(strokeW))

        // Body & Base
        val bodyPath = Path().apply {
            moveTo(cx - w * 0.10f, headCenterY + headRadius * 0.7f)
            quadraticTo(cx - w * 0.08f, h * 0.58f, cx - w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.24f, h * 0.78f)
            quadraticTo(cx + w * 0.08f, h * 0.58f, cx + w * 0.10f, headCenterY + headRadius * 0.7f)
            close()
        }
        drawPath(bodyPath, color = fill, style = Fill)
        drawPath(bodyPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Base pedestal
        val basePath = Path().apply {
            moveTo(cx - w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.30f, h * 0.88f)
            close()
        }
        drawPath(basePath, color = fill, style = Fill)
        drawPath(basePath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Accent detail line on collar
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.12f, h * 0.48f),
            end = Offset(cx + w * 0.12f, h * 0.48f),
            strokeWidth = strokeW * 0.7f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawStauntonKnight(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Classic sculpted Knight profile
        val knightPath = Path().apply {
            moveTo(cx - w * 0.26f, h * 0.82f)
            lineTo(cx + w * 0.26f, h * 0.82f)
            lineTo(cx + w * 0.22f, h * 0.76f)
            // Back of neck & mane
            quadraticTo(cx + w * 0.20f, h * 0.52f, cx + w * 0.12f, h * 0.30f)
            // Ear tip
            lineTo(cx + w * 0.06f, h * 0.16f)
            lineTo(cx - w * 0.02f, h * 0.24f)
            // Forehead
            lineTo(cx - w * 0.12f, h * 0.26f)
            // Snout / muzzle
            quadraticTo(cx - w * 0.32f, h * 0.36f, cx - w * 0.28f, h * 0.46f)
            // Mouth
            lineTo(cx - w * 0.18f, h * 0.48f)
            // Chin / throat
            quadraticTo(cx - w * 0.06f, h * 0.54f, cx - w * 0.14f, h * 0.76f)
            close()
        }
        drawPath(knightPath, color = fill, style = Fill)
        drawPath(knightPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Base pedestal
        val basePath = Path().apply {
            moveTo(cx - w * 0.32f, h * 0.88f)
            lineTo(cx - w * 0.26f, h * 0.82f)
            lineTo(cx + w * 0.26f, h * 0.82f)
            lineTo(cx + w * 0.32f, h * 0.88f)
            close()
        }
        drawPath(basePath, color = fill, style = Fill)
        drawPath(basePath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Eye
        drawCircle(
            color = detail,
            radius = w * 0.032f,
            center = Offset(cx - w * 0.08f, h * 0.34f)
        )

        // Mane notch lines
        drawLine(
            color = detail,
            start = Offset(cx + w * 0.04f, h * 0.32f),
            end = Offset(cx + w * 0.14f, h * 0.38f),
            strokeWidth = strokeW * 0.7f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = detail,
            start = Offset(cx + w * 0.06f, h * 0.44f),
            end = Offset(cx + w * 0.17f, h * 0.50f),
            strokeWidth = strokeW * 0.7f,
            cap = StrokeCap.Round
        )
        // Nostril line
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.22f, h * 0.42f),
            end = Offset(cx - w * 0.18f, h * 0.44f),
            strokeWidth = strokeW * 0.7f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawStauntonBishop(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Top finial ball
        drawCircle(color = fill, radius = w * 0.045f, center = Offset(cx, h * 0.16f))
        drawCircle(color = outline, radius = w * 0.045f, center = Offset(cx, h * 0.16f), style = Stroke(strokeW))

        // Mitre head
        val mitrePath = Path().apply {
            moveTo(cx, h * 0.20f)
            cubicTo(cx + w * 0.24f, h * 0.28f, cx + w * 0.22f, h * 0.52f, cx + w * 0.12f, h * 0.58f)
            lineTo(cx - w * 0.12f, h * 0.58f)
            cubicTo(cx - w * 0.22f, h * 0.52f, cx - w * 0.24f, h * 0.28f, cx, h * 0.20f)
            close()
        }
        drawPath(mitrePath, color = fill, style = Fill)
        drawPath(mitrePath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Mitre slash / notch
        val slashPath = Path().apply {
            moveTo(cx + w * 0.08f, h * 0.26f)
            lineTo(cx - w * 0.05f, h * 0.40f)
        }
        drawPath(slashPath, color = detail, style = Stroke(strokeW * 0.9f, cap = StrokeCap.Round))

        // Collar ring
        drawRoundRect(
            color = fill,
            topLeft = Offset(cx - w * 0.16f, h * 0.58f),
            size = Size(w * 0.32f, h * 0.06f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
        )
        drawRoundRect(
            color = outline,
            topLeft = Offset(cx - w * 0.16f, h * 0.58f),
            size = Size(w * 0.32f, h * 0.06f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
            style = Stroke(strokeW)
        )

        // Body & Base
        val bodyPath = Path().apply {
            moveTo(cx - w * 0.14f, h * 0.64f)
            quadraticTo(cx - w * 0.12f, h * 0.72f, cx - w * 0.24f, h * 0.80f)
            lineTo(cx + w * 0.24f, h * 0.80f)
            quadraticTo(cx + w * 0.12f, h * 0.72f, cx + w * 0.14f, h * 0.64f)
            close()
        }
        drawPath(bodyPath, color = fill, style = Fill)
        drawPath(bodyPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Base pedestal
        val basePath = Path().apply {
            moveTo(cx - w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.24f, h * 0.80f)
            lineTo(cx + w * 0.24f, h * 0.80f)
            lineTo(cx + w * 0.30f, h * 0.88f)
            close()
        }
        drawPath(basePath, color = fill, style = Fill)
        drawPath(basePath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))
    }

    private fun DrawScope.drawStauntonRook(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Crenellated crown & Tower
        val rookPath = Path().apply {
            // Crown top left crenel
            moveTo(cx - w * 0.22f, h * 0.24f)
            lineTo(cx - w * 0.22f, h * 0.18f)
            lineTo(cx - w * 0.14f, h * 0.18f)
            lineTo(cx - w * 0.14f, h * 0.24f)
            // Middle crenel gap
            lineTo(cx - w * 0.06f, h * 0.24f)
            lineTo(cx - w * 0.06f, h * 0.18f)
            lineTo(cx + w * 0.06f, h * 0.18f)
            lineTo(cx + w * 0.06f, h * 0.24f)
            // Right crenel
            lineTo(cx + w * 0.14f, h * 0.24f)
            lineTo(cx + w * 0.14f, h * 0.18f)
            lineTo(cx + w * 0.22f, h * 0.18f)
            lineTo(cx + w * 0.22f, h * 0.28f)
            // Waist in
            lineTo(cx + w * 0.18f, h * 0.32f)
            // Tower shaft
            lineTo(cx + w * 0.16f, h * 0.74f)
            lineTo(cx + w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.28f, h * 0.88f)
            lineTo(cx - w * 0.28f, h * 0.88f)
            lineTo(cx - w * 0.24f, h * 0.78f)
            lineTo(cx - w * 0.16f, h * 0.74f)
            lineTo(cx - w * 0.18f, h * 0.32f)
            lineTo(cx - w * 0.22f, h * 0.28f)
            close()
        }
        drawPath(rookPath, color = fill, style = Fill)
        drawPath(rookPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Horizontal ridge under battlements
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.18f, h * 0.32f),
            end = Offset(cx + w * 0.18f, h * 0.32f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )

        // Lower base ridge
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.24f, h * 0.78f),
            end = Offset(cx + w * 0.24f, h * 0.78f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawStauntonQueen(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Coronet pearls (5 pearls)
        val pearlRadius = w * 0.034f
        val pearlY = h * 0.18f
        val pearlXOffsets = arrayOf(-0.24f, -0.12f, 0f, 0.12f, 0.24f)
        for (off in pearlXOffsets) {
            val px = cx + w * off
            val py = if (off == 0f) pearlY - h * 0.02f else pearlY
            drawCircle(color = fill, radius = pearlRadius, center = Offset(px, py))
            drawCircle(color = outline, radius = pearlRadius, center = Offset(px, py), style = Stroke(strokeW))
        }

        // Coronet body
        val queenPath = Path().apply {
            moveTo(cx - w * 0.24f, pearlY + pearlRadius)
            lineTo(cx - w * 0.15f, h * 0.32f)
            lineTo(cx - w * 0.12f, pearlY + pearlRadius)
            lineTo(cx - w * 0.06f, h * 0.32f)
            lineTo(cx, pearlY - h * 0.02f + pearlRadius)
            lineTo(cx + w * 0.06f, h * 0.32f)
            lineTo(cx + w * 0.12f, pearlY + pearlRadius)
            lineTo(cx + w * 0.15f, h * 0.32f)
            lineTo(cx + w * 0.24f, pearlY + pearlRadius)
            // Flared torso
            quadraticTo(cx + w * 0.20f, h * 0.50f, cx + w * 0.14f, h * 0.60f)
            // Body waist
            lineTo(cx + w * 0.22f, h * 0.76f)
            lineTo(cx + w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.22f, h * 0.76f)
            lineTo(cx - w * 0.14f, h * 0.60f)
            quadraticTo(cx - w * 0.20f, h * 0.50f, cx - w * 0.24f, pearlY + pearlRadius)
            close()
        }
        drawPath(queenPath, color = fill, style = Fill)
        drawPath(queenPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Royal waistband detail
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.14f, h * 0.60f),
            end = Offset(cx + w * 0.14f, h * 0.60f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.22f, h * 0.76f),
            end = Offset(cx + w * 0.22f, h * 0.76f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawStauntonKing(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.045f

        // Top Cross
        val crossH = h * 0.14f
        val crossW = w * 0.10f
        val crossTop = h * 0.06f
        // Vertical cross bar
        drawLine(
            color = outline,
            start = Offset(cx, crossTop),
            end = Offset(cx, crossTop + crossH),
            strokeWidth = strokeW * 1.1f,
            cap = StrokeCap.Square
        )
        // Horizontal cross bar
        drawLine(
            color = outline,
            start = Offset(cx - crossW / 2, crossTop + crossH * 0.38f),
            end = Offset(cx + crossW / 2, crossTop + crossH * 0.38f),
            strokeWidth = strokeW * 1.1f,
            cap = StrokeCap.Square
        )

        // Crown bulb & Mantle
        val kingPath = Path().apply {
            moveTo(cx, crossTop + crossH)
            cubicTo(cx + w * 0.26f, h * 0.24f, cx + w * 0.22f, h * 0.44f, cx + w * 0.14f, h * 0.56f)
            lineTo(cx + w * 0.22f, h * 0.76f)
            lineTo(cx + w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.30f, h * 0.88f)
            lineTo(cx - w * 0.22f, h * 0.76f)
            lineTo(cx - w * 0.14f, h * 0.56f)
            cubicTo(cx - w * 0.22f, h * 0.44f, cx - w * 0.26f, h * 0.24f, cx, crossTop + crossH)
            close()
        }
        drawPath(kingPath, color = fill, style = Fill)
        drawPath(kingPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        // Center jewel / cross contour
        drawLine(
            color = detail,
            start = Offset(cx, crossTop + crossH + h * 0.02f),
            end = Offset(cx, h * 0.44f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )

        // Crown collar arc
        val collarArc = Path().apply {
            moveTo(cx - w * 0.18f, h * 0.38f)
            quadraticTo(cx, h * 0.44f, cx + w * 0.18f, h * 0.38f)
        }
        drawPath(collarArc, color = detail, style = Stroke(strokeW * 0.8f, cap = StrokeCap.Round))

        // Lower pedestal bar
        drawLine(
            color = detail,
            start = Offset(cx - w * 0.22f, h * 0.76f),
            end = Offset(cx + w * 0.22f, h * 0.76f),
            strokeWidth = strokeW * 0.8f,
            cap = StrokeCap.Round
        )
    }

    // --- CLASSIC TOURNAMENT STYLE ---
    private fun DrawScope.drawClassicPawn(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.055f

        drawCircle(color = fill, radius = w * 0.17f, center = Offset(cx, h * 0.30f))
        drawCircle(color = outline, radius = w * 0.17f, center = Offset(cx, h * 0.30f), style = Stroke(strokeW))

        val path = Path().apply {
            moveTo(cx - w * 0.11f, h * 0.44f)
            lineTo(cx - w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.24f, h * 0.78f)
            lineTo(cx + w * 0.11f, h * 0.44f)
            close()
        }
        drawPath(path, color = fill, style = Fill)
        drawPath(path, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawRoundRect(
            color = fill,
            topLeft = Offset(cx - w * 0.28f, h * 0.78f),
            size = Size(w * 0.56f, h * 0.12f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
        )
        drawRoundRect(
            color = outline,
            topLeft = Offset(cx - w * 0.28f, h * 0.78f),
            size = Size(w * 0.56f, h * 0.12f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f),
            style = Stroke(strokeW)
        )
    }

    private fun DrawScope.drawClassicKnight(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        drawStauntonKnight(fill, detail, outline, isWhite)
    }

    private fun DrawScope.drawClassicBishop(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        drawStauntonBishop(fill, detail, outline, isWhite)
    }

    private fun DrawScope.drawClassicRook(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        drawStauntonRook(fill, detail, outline, isWhite)
    }

    private fun DrawScope.drawClassicQueen(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        drawStauntonQueen(fill, detail, outline, isWhite)
    }

    private fun DrawScope.drawClassicKing(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        drawStauntonKing(fill, detail, outline, isWhite)
    }

    // --- MINIMAL MODERN GEOMETRIC STYLE ---
    private fun DrawScope.drawMinimalPawn(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        drawCircle(color = fill, radius = w * 0.14f, center = Offset(cx, h * 0.32f))
        drawCircle(color = outline, radius = w * 0.14f, center = Offset(cx, h * 0.32f), style = Stroke(strokeW))

        val path = Path().apply {
            moveTo(cx, h * 0.46f)
            lineTo(cx - w * 0.22f, h * 0.82f)
            lineTo(cx + w * 0.22f, h * 0.82f)
            close()
        }
        drawPath(path, color = fill, style = Fill)
        drawPath(path, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.26f, h * 0.85f),
            end = Offset(cx + w * 0.26f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawMinimalKnight(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        val path = Path().apply {
            moveTo(cx - w * 0.22f, h * 0.82f)
            lineTo(cx + w * 0.22f, h * 0.82f)
            lineTo(cx + w * 0.18f, h * 0.36f)
            lineTo(cx + w * 0.08f, h * 0.20f)
            lineTo(cx - w * 0.04f, h * 0.26f)
            lineTo(cx - w * 0.24f, h * 0.40f)
            lineTo(cx - w * 0.16f, h * 0.52f)
            lineTo(cx - w * 0.08f, h * 0.54f)
            lineTo(cx - w * 0.16f, h * 0.82f)
            close()
        }
        drawPath(path, color = fill, style = Fill)
        drawPath(path, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawCircle(color = detail, radius = w * 0.028f, center = Offset(cx - w * 0.06f, h * 0.36f))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.26f, h * 0.85f),
            end = Offset(cx + w * 0.26f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawMinimalBishop(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        drawCircle(color = fill, radius = w * 0.04f, center = Offset(cx, h * 0.20f))
        drawCircle(color = outline, radius = w * 0.04f, center = Offset(cx, h * 0.20f), style = Stroke(strokeW))

        val path = Path().apply {
            moveTo(cx, h * 0.25f)
            lineTo(cx + w * 0.18f, h * 0.52f)
            lineTo(cx - w * 0.18f, h * 0.52f)
            close()
        }
        drawPath(path, color = fill, style = Fill)
        drawPath(path, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = detail,
            start = Offset(cx + w * 0.06f, h * 0.32f),
            end = Offset(cx - w * 0.04f, h * 0.44f),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )

        val stemPath = Path().apply {
            moveTo(cx - w * 0.10f, h * 0.52f)
            lineTo(cx - w * 0.20f, h * 0.82f)
            lineTo(cx + w * 0.20f, h * 0.82f)
            lineTo(cx + w * 0.10f, h * 0.52f)
            close()
        }
        drawPath(stemPath, color = fill, style = Fill)
        drawPath(stemPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.26f, h * 0.85f),
            end = Offset(cx + w * 0.26f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawMinimalRook(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        val path = Path().apply {
            moveTo(cx - w * 0.20f, h * 0.22f)
            lineTo(cx - w * 0.20f, h * 0.32f)
            lineTo(cx - w * 0.15f, h * 0.38f)
            lineTo(cx - w * 0.15f, h * 0.80f)
            lineTo(cx + w * 0.15f, h * 0.80f)
            lineTo(cx + w * 0.15f, h * 0.38f)
            lineTo(cx + w * 0.20f, h * 0.32f)
            lineTo(cx + w * 0.20f, h * 0.22f)
            // Crenels
            lineTo(cx + w * 0.13f, h * 0.22f)
            lineTo(cx + w * 0.13f, h * 0.27f)
            lineTo(cx + w * 0.04f, h * 0.27f)
            lineTo(cx + w * 0.04f, h * 0.22f)
            lineTo(cx - w * 0.04f, h * 0.22f)
            lineTo(cx - w * 0.04f, h * 0.27f)
            lineTo(cx - w * 0.13f, h * 0.27f)
            lineTo(cx - w * 0.13f, h * 0.22f)
            close()
        }
        drawPath(path, color = fill, style = Fill)
        drawPath(path, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.26f, h * 0.85f),
            end = Offset(cx + w * 0.26f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawMinimalQueen(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        drawCircle(color = fill, radius = w * 0.04f, center = Offset(cx, h * 0.18f))
        drawCircle(color = outline, radius = w * 0.04f, center = Offset(cx, h * 0.18f), style = Stroke(strokeW))

        val crownPath = Path().apply {
            moveTo(cx - w * 0.22f, h * 0.26f)
            lineTo(cx - w * 0.11f, h * 0.38f)
            lineTo(cx, h * 0.24f)
            lineTo(cx + w * 0.11f, h * 0.38f)
            lineTo(cx + w * 0.22f, h * 0.26f)
            lineTo(cx + w * 0.16f, h * 0.54f)
            lineTo(cx - w * 0.16f, h * 0.54f)
            close()
        }
        drawPath(crownPath, color = fill, style = Fill)
        drawPath(crownPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        val skirtPath = Path().apply {
            moveTo(cx - w * 0.14f, h * 0.54f)
            lineTo(cx - w * 0.24f, h * 0.82f)
            lineTo(cx + w * 0.24f, h * 0.82f)
            lineTo(cx + w * 0.14f, h * 0.54f)
            close()
        }
        drawPath(skirtPath, color = fill, style = Fill)
        drawPath(skirtPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.28f, h * 0.85f),
            end = Offset(cx + w * 0.28f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }

    private fun DrawScope.drawMinimalKing(fill: Color, detail: Color, outline: Color, isWhite: Boolean) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val strokeW = w * 0.042f

        // Clean Cross
        drawLine(
            color = outline,
            start = Offset(cx, h * 0.10f),
            end = Offset(cx, h * 0.24f),
            strokeWidth = strokeW * 1.1f,
            cap = StrokeCap.Square
        )
        drawLine(
            color = outline,
            start = Offset(cx - w * 0.07f, h * 0.16f),
            end = Offset(cx + w * 0.07f, h * 0.16f),
            strokeWidth = strokeW * 1.1f,
            cap = StrokeCap.Square
        )

        val mantlePath = Path().apply {
            moveTo(cx, h * 0.24f)
            lineTo(cx + w * 0.22f, h * 0.44f)
            lineTo(cx + w * 0.14f, h * 0.56f)
            lineTo(cx - w * 0.14f, h * 0.56f)
            lineTo(cx - w * 0.22f, h * 0.44f)
            close()
        }
        drawPath(mantlePath, color = fill, style = Fill)
        drawPath(mantlePath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        val skirtPath = Path().apply {
            moveTo(cx - w * 0.14f, h * 0.56f)
            lineTo(cx - w * 0.24f, h * 0.82f)
            lineTo(cx + w * 0.24f, h * 0.82f)
            lineTo(cx + w * 0.14f, h * 0.56f)
            close()
        }
        drawPath(skirtPath, color = fill, style = Fill)
        drawPath(skirtPath, color = outline, style = Stroke(strokeW, join = StrokeJoin.Round))

        drawLine(
            color = outline,
            start = Offset(cx - w * 0.28f, h * 0.85f),
            end = Offset(cx + w * 0.28f, h * 0.85f),
            strokeWidth = strokeW * 1.2f,
            cap = StrokeCap.Round
        )
    }
}
