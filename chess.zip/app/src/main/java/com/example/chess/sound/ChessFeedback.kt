package com.example.chess.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Low-latency audio and haptic feedback system for chess gameplay.
 * Uses direct PCM 16-bit synthesis via AudioTrack to ensure zero-latency response
 * and avoid Codec2/MediaCodec decoder queries on emulator environments.
 */
class ChessFeedback(context: Context) {
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val sampleRate = 22050

    private val audioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private val audioFormat = AudioFormat.Builder()
        .setSampleRate(sampleRate)
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
        .build()

    // Pre-synthesized static AudioTracks for instant, zero-latency playback
    private var moveTrack: AudioTrack? = null
    private var captureTrack: AudioTrack? = null
    private var castleTrack: AudioTrack? = null
    private var checkTrack: AudioTrack? = null
    private var gameOverTrack: AudioTrack? = null

    init {
        try {
            moveTrack = createStaticTrack(synthesizeMoveSound())
            captureTrack = createStaticTrack(synthesizeCaptureSound())
            castleTrack = createStaticTrack(synthesizeCastleSound())
            checkTrack = createStaticTrack(synthesizeCheckSound())
            gameOverTrack = createStaticTrack(synthesizeGameOverSound())
        } catch (_: Exception) {
            // Graceful fallback if device audio track cannot be initialized
        }
    }

    fun playMove(soundEnabled: Boolean, hapticsEnabled: Boolean, isCastling: Boolean = false) {
        if (hapticsEnabled) vibrate(16)
        if (soundEnabled) {
            val track = if (isCastling && castleTrack != null) castleTrack else moveTrack
            playTrack(track, volume = 0.85f)
        }
    }

    fun playCapture(soundEnabled: Boolean, hapticsEnabled: Boolean) {
        if (hapticsEnabled) vibrate(32)
        if (soundEnabled) {
            playTrack(captureTrack, volume = 0.90f)
        }
    }

    fun playCheck(soundEnabled: Boolean, hapticsEnabled: Boolean) {
        if (hapticsEnabled) vibratePattern(longArrayOf(0, 20, 50, 30))
        if (soundEnabled) {
            playTrack(checkTrack, volume = 0.85f)
        }
    }

    fun playGameOver(soundEnabled: Boolean, hapticsEnabled: Boolean) {
        if (hapticsEnabled) vibratePattern(longArrayOf(0, 35, 60, 60))
        if (soundEnabled) {
            playTrack(gameOverTrack, volume = 0.90f)
        }
    }

    fun release() {
        listOf(moveTrack, captureTrack, castleTrack, checkTrack, gameOverTrack).forEach { track ->
            try {
                track?.stop()
                track?.release()
            } catch (_: Exception) {
                // Ignore
            }
        }
    }

    private fun playTrack(track: AudioTrack?, volume: Float) {
        if (track == null) return
        try {
            if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                track.stop()
            }
            track.reloadStaticData()
            track.setVolume(volume.coerceIn(0f, 1f))
            track.play()
        } catch (_: Exception) {
            // Ignore audio playback exceptions
        }
    }

    private fun createStaticTrack(pcmData: ShortArray): AudioTrack? {
        return try {
            val bufferSize = pcmData.size * 2
            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcmData, 0, pcmData.size)
            track
        } catch (_: Exception) {
            null
        }
    }

    // Natural wood tap: warm sine fundamental with rapid exponential decay + subtle body click
    private fun synthesizeMoveSound(): ShortArray {
        val durationMs = 85
        val numSamples = (sampleRate * durationMs) / 1000
        val pcm = ShortArray(numSamples)
        val freq = 290.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 55.0)
            val tone = sin(2.0 * PI * freq * t)
            val harmonic = 0.3 * sin(2.0 * PI * freq * 1.95 * t) * exp(-t * 80.0)
            val click = (Math.random() * 2.0 - 1.0) * exp(-t * 140.0) * 0.2
            val sample = (tone + harmonic + click) * env * 0.8
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
        return pcm
    }

    // Crisp wood capture: sharper wood impact with overtone
    private fun synthesizeCaptureSound(): ShortArray {
        val durationMs = 110
        val numSamples = (sampleRate * durationMs) / 1000
        val pcm = ShortArray(numSamples)
        val freq1 = 380.0
        val freq2 = 460.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env1 = exp(-t * 45.0)
            val t2 = (t - 0.015).coerceAtLeast(0.0)
            val env2 = if (t >= 0.015) exp(-t2 * 60.0) * 0.7 else 0.0

            val tone1 = sin(2.0 * PI * freq1 * t) * env1
            val tone2 = sin(2.0 * PI * freq2 * t2) * env2
            val click = (Math.random() * 2.0 - 1.0) * exp(-t * 120.0) * 0.35
            val sample = (tone1 + tone2 + click) * 0.75
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
        return pcm
    }

    // Castling: double wood tap
    private fun synthesizeCastleSound(): ShortArray {
        val durationMs = 180
        val numSamples = (sampleRate * durationMs) / 1000
        val pcm = ShortArray(numSamples)

        val freq1 = 280.0
        val freq2 = 330.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env1 = exp(-t * 50.0)
            val t2 = (t - 0.080).coerceAtLeast(0.0)
            val env2 = if (t >= 0.080) exp(-t2 * 50.0) * 0.85 else 0.0

            val tone1 = sin(2.0 * PI * freq1 * t) * env1
            val tone2 = sin(2.0 * PI * freq2 * t2) * env2
            val click = (Math.random() * 2.0 - 1.0) * (exp(-t * 140.0) + if (t >= 0.080) exp(-t2 * 140.0) * 0.85 else 0.0) * 0.15
            val sample = (tone1 + tone2 + click) * 0.75
            pcm[i] = (sample.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
        return pcm
    }

    // Check: elegant crystalline chime (C5 523Hz + E5 659Hz)
    private fun synthesizeCheckSound(): ShortArray {
        val durationMs = 240
        val numSamples = (sampleRate * durationMs) / 1000
        val pcm = ShortArray(numSamples)
        val f1 = 523.25
        val f2 = 659.25

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 9.0)
            val tone = (sin(2.0 * PI * f1 * t) * 0.55 + sin(2.0 * PI * f2 * t) * 0.45) * env
            pcm[i] = (tone.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
        return pcm
    }

    // Game Over: serene resolution chord (C4 261Hz + E4 329Hz + G4 392Hz)
    private fun synthesizeGameOverSound(): ShortArray {
        val durationMs = 380
        val numSamples = (sampleRate * durationMs) / 1000
        val pcm = ShortArray(numSamples)
        val f1 = 261.63
        val f2 = 329.63
        val f3 = 392.00

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 6.5)
            val tone = (sin(2.0 * PI * f1 * t) * 0.38 + sin(2.0 * PI * f2 * t) * 0.34 + sin(2.0 * PI * f3 * t) * 0.28) * env
            pcm[i] = (tone.coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
        }
        return pcm
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {
            // Ignore if vibration permissions are restricted
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (_: Exception) {
            // Ignore
        }
    }
}
