package com.example.chess.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chess.ai.ChessEngineAi
import com.example.chess.data.GamePreferences
import com.example.chess.engine.ChessBoard
import com.example.chess.model.AiDifficulty
import com.example.chess.model.BoardTheme
import com.example.chess.model.GameMode
import com.example.chess.model.GameStatus
import com.example.chess.model.Move
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.model.TimeControl
import com.example.chess.sound.ChessFeedback
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class Screen {
    OPENING,
    HOME,
    DIFFICULTY_SELECTION,
    GAME,
    SETTINGS
}

data class ChessUiState(
    val currentScreen: Screen = Screen.OPENING,
    val gameMode: GameMode = GameMode.VS_AI,
    val difficulty: AiDifficulty = AiDifficulty.LEVEL_5,
    val timeControl: TimeControl = TimeControl.TEN_MIN,
    val theme: BoardTheme = BoardTheme.CLASSIC,
    val board: ChessBoard = ChessBoard.createStartingBoard(),
    val selectedSquare: Square? = null,
    val legalTargetSquares: List<Square> = emptyList(),
    val lastMove: Move? = null,
    val pendingPromotionFromTo: Pair<Square, Square>? = null,
    val gameStatus: GameStatus = GameStatus.ACTIVE,
    val statusMessage: String? = null,
    val whiteTimeSeconds: Int = 600,
    val blackTimeSeconds: Int = 600,
    val isTimerActive: Boolean = false,
    val isBoardFlipped: Boolean = false,
    val isAiThinking: Boolean = false,
    val showResignConfirm: Boolean = false,
    val showDrawOfferConfirm: Boolean = false,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val showCoordinates: Boolean = true,
    val showLegalMoves: Boolean = true,
    val moveAnimation: Boolean = true,
    val confirmResignation: Boolean = true,
    val autoFlipBoard: Boolean = false,
    val pieceStyle: com.example.chess.model.PieceStyle = com.example.chess.model.PieceStyle.STAUNTON,
    val boardVersion: Long = 0L // Incremented on board updates to trigger recomposition
)

class ChessViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = GamePreferences(application)
    private val feedback = ChessFeedback(application)

    private val _uiState = MutableStateFlow(
        ChessUiState(
            soundEnabled = prefs.soundEnabled,
            hapticsEnabled = prefs.hapticsEnabled,
            showCoordinates = prefs.showCoordinates,
            showLegalMoves = prefs.showLegalMoves,
            moveAnimation = prefs.moveAnimation,
            confirmResignation = prefs.confirmResignation,
            autoFlipBoard = prefs.autoFlipBoard,
            theme = BoardTheme.fromId(prefs.selectedThemeId),
            pieceStyle = com.example.chess.model.PieceStyle.fromId(prefs.pieceStyleId),
            difficulty = AiDifficulty.fromLevel(prefs.difficultyLevel),
            timeControl = TimeControl.fromId(prefs.timeControlId)
        )
    )
    val uiState: StateFlow<ChessUiState> = _uiState.asStateFlow()

    private var clockJob: Job? = null
    private var aiJob: Job? = null
    private val boardSnapshotHistory = mutableListOf<ChessBoard>()

    init {
        saveSnapshot()
    }

    private fun saveSnapshot() {
        boardSnapshotHistory.add(_uiState.value.board.copy())
    }

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun selectDifficulty(difficulty: AiDifficulty) {
        prefs.difficultyLevel = difficulty.level
        _uiState.update { it.copy(difficulty = difficulty) }
    }

    fun selectTimeControl(timeControl: TimeControl) {
        prefs.timeControlId = timeControl.id
        _uiState.update { it.copy(timeControl = timeControl) }
    }

    fun selectTheme(theme: BoardTheme) {
        prefs.selectedThemeId = theme.id
        _uiState.update { it.copy(theme = theme) }
    }

    fun selectPieceStyle(pieceStyle: com.example.chess.model.PieceStyle) {
        prefs.pieceStyleId = pieceStyle.id
        _uiState.update { it.copy(pieceStyle = pieceStyle) }
    }

    fun startNewGame(mode: GameMode, difficulty: AiDifficulty = _uiState.value.difficulty, timeControl: TimeControl = _uiState.value.timeControl) {
        clockJob?.cancel()
        aiJob?.cancel()

        val newBoard = ChessBoard.createStartingBoard()
        boardSnapshotHistory.clear()
        boardSnapshotHistory.add(newBoard.copy())

        val initialSeconds = timeControl.totalSeconds

        _uiState.update {
            it.copy(
                currentScreen = Screen.GAME,
                gameMode = mode,
                difficulty = difficulty,
                timeControl = timeControl,
                board = newBoard,
                selectedSquare = null,
                legalTargetSquares = emptyList(),
                lastMove = null,
                pendingPromotionFromTo = null,
                gameStatus = GameStatus.ACTIVE,
                statusMessage = null,
                whiteTimeSeconds = initialSeconds,
                blackTimeSeconds = initialSeconds,
                isTimerActive = !timeControl.isUnlimited,
                isBoardFlipped = false,
                isAiThinking = false,
                showResignConfirm = false,
                showDrawOfferConfirm = false,
                boardVersion = it.boardVersion + 1
            )
        }

        if (!timeControl.isUnlimited) {
            startClockTicker()
        }
    }

    fun restartGame() {
        startNewGame(
            mode = _uiState.value.gameMode,
            difficulty = _uiState.value.difficulty,
            timeControl = _uiState.value.timeControl
        )
    }

    fun toggleFlipBoard() {
        _uiState.update { it.copy(isBoardFlipped = !it.isBoardFlipped) }
    }

    fun onSquareClicked(square: Square) {
        val state = _uiState.value
        if (state.gameStatus.isGameOver || state.isAiThinking) return

        // If human vs AI, only allow human moves when it is White's turn
        if (state.gameMode == GameMode.VS_AI && state.board.activeColor == PieceColor.BLACK) {
            return
        }

        val clickedPiece = state.board.getPiece(square)
        val selectedSquare = state.selectedSquare

        // 1. If clicking already selected square, deselect
        if (selectedSquare == square) {
            _uiState.update { it.copy(selectedSquare = null, legalTargetSquares = emptyList()) }
            return
        }

        // 2. If clicking one of the legal targets, attempt move
        if (selectedSquare != null && state.legalTargetSquares.contains(square)) {
            val movingPiece = state.board.getPiece(selectedSquare) ?: return

            // Check if this move is a pawn promotion
            val isPromotion = movingPiece.type == PieceType.PAWN &&
                    ((movingPiece.color == PieceColor.WHITE && square.rank == 7) ||
                            (movingPiece.color == PieceColor.BLACK && square.rank == 0))

            if (isPromotion) {
                _uiState.update {
                    it.copy(
                        pendingPromotionFromTo = Pair(selectedSquare, square),
                        selectedSquare = null,
                        legalTargetSquares = emptyList()
                    )
                }
                return
            }

            // Normal move or capture
            executePlayerMove(selectedSquare, square, null)
            return
        }

        // 3. If clicking a piece of current player's color, select it and show legal moves
        if (clickedPiece != null && clickedPiece.color == state.board.activeColor) {
            val legalMoves = state.board.getLegalMovesForSquare(square)
            val targets = legalMoves.map { it.to }
            _uiState.update {
                it.copy(
                    selectedSquare = square,
                    legalTargetSquares = targets
                )
            }
        } else {
            // Clicked empty square or opponent piece with no current selection
            _uiState.update { it.copy(selectedSquare = null, legalTargetSquares = emptyList()) }
        }
    }

    fun onPromotionPieceSelected(pieceType: PieceType) {
        val pending = _uiState.value.pendingPromotionFromTo ?: return
        _uiState.update { it.copy(pendingPromotionFromTo = null) }
        executePlayerMove(pending.first, pending.second, pieceType)
    }

    fun dismissPromotionDialog() {
        _uiState.update { it.copy(pendingPromotionFromTo = null) }
    }

    private fun executePlayerMove(from: Square, to: Square, promotion: PieceType?) {
        val currentBoard = _uiState.value.board
        val move = Move(from = from, to = to, promotion = promotion)
        val success = currentBoard.makeMove(move)

        if (success) {
            // Find the enriched move with SAN
            val executedMove = currentBoard.getMoveHistory().lastOrNull() ?: move
            saveSnapshot()

            val newStatus = currentBoard.getGameStatus()
            val state = _uiState.value

            // Sounds & Haptics
            if (executedMove.isCapture) {
                feedback.playCapture(state.soundEnabled, state.hapticsEnabled)
            } else {
                feedback.playMove(state.soundEnabled, state.hapticsEnabled, executedMove.isCastling)
            }
            if (newStatus == GameStatus.CHECK) {
                feedback.playCheck(state.soundEnabled, state.hapticsEnabled)
            } else if (newStatus.isGameOver) {
                feedback.playGameOver(state.soundEnabled, state.hapticsEnabled)
                clockJob?.cancel()
            }

            // Auto-flip for local 2-player mode if enabled
            val newFlipped = if (state.gameMode == GameMode.LOCAL_FRIEND && state.autoFlipBoard) {
                currentBoard.activeColor == PieceColor.BLACK
            } else {
                state.isBoardFlipped
            }

            _uiState.update {
                it.copy(
                    selectedSquare = null,
                    legalTargetSquares = emptyList(),
                    lastMove = executedMove,
                    gameStatus = newStatus,
                    isBoardFlipped = newFlipped,
                    boardVersion = it.boardVersion + 1
                )
            }

            // Trigger AI response if playing vs AI and game is still active
            if (state.gameMode == GameMode.VS_AI && !newStatus.isGameOver && currentBoard.activeColor == PieceColor.BLACK) {
                triggerAiMove()
            }
        }
    }

    private fun triggerAiMove() {
        aiJob?.cancel()
        _uiState.update { it.copy(isAiThinking = true) }

        aiJob = viewModelScope.launch {
            val boardCopy = _uiState.value.board.copy()
            val aiMove = ChessEngineAi.findBestMove(boardCopy, _uiState.value.difficulty)

            if (aiMove != null && isActive) {
                val currentBoard = _uiState.value.board
                val success = currentBoard.makeMove(aiMove)

                if (success) {
                    val executedMove = currentBoard.getMoveHistory().lastOrNull() ?: aiMove
                    saveSnapshot()
                    val newStatus = currentBoard.getGameStatus()
                    val state = _uiState.value

                    if (executedMove.isCapture) {
                        feedback.playCapture(state.soundEnabled, state.hapticsEnabled)
                    } else {
                        feedback.playMove(state.soundEnabled, state.hapticsEnabled, executedMove.isCastling)
                    }
                    if (newStatus == GameStatus.CHECK) {
                        feedback.playCheck(state.soundEnabled, state.hapticsEnabled)
                    } else if (newStatus.isGameOver) {
                        feedback.playGameOver(state.soundEnabled, state.hapticsEnabled)
                        clockJob?.cancel()
                    }

                    _uiState.update {
                        it.copy(
                            isAiThinking = false,
                            lastMove = executedMove,
                            gameStatus = newStatus,
                            boardVersion = it.boardVersion + 1
                        )
                    }
                } else {
                    _uiState.update { it.copy(isAiThinking = false) }
                }
            } else {
                _uiState.update { it.copy(isAiThinking = false) }
            }
        }
    }

    fun undoMove() {
        val state = _uiState.value
        if (state.isAiThinking) return

        // In AI mode, undo 2 moves (AI move + human move)
        // In Local Friend mode, undo 1 move
        val movesToUndo = if (state.gameMode == GameMode.VS_AI) 2 else 1
        if (boardSnapshotHistory.size <= 1) return

        val targetIndex = (boardSnapshotHistory.size - 1 - movesToUndo).coerceAtLeast(0)
        while (boardSnapshotHistory.size > targetIndex + 1) {
            boardSnapshotHistory.removeAt(boardSnapshotHistory.size - 1)
        }

        val restoredBoard = boardSnapshotHistory.last().copy()
        val lastMove = restoredBoard.getMoveHistory().lastOrNull()

        _uiState.update {
            it.copy(
                board = restoredBoard,
                selectedSquare = null,
                legalTargetSquares = emptyList(),
                lastMove = lastMove,
                gameStatus = restoredBoard.getGameStatus(),
                pendingPromotionFromTo = null,
                boardVersion = it.boardVersion + 1
            )
        }
    }

    fun requestResign() {
        if (_uiState.value.confirmResignation) {
            _uiState.update { it.copy(showResignConfirm = true) }
        } else {
            confirmResign()
        }
    }

    fun cancelResign() {
        _uiState.update { it.copy(showResignConfirm = false) }
    }

    fun confirmResign() {
        clockJob?.cancel()
        feedback.playGameOver(_uiState.value.soundEnabled, _uiState.value.hapticsEnabled)
        _uiState.update {
            it.copy(
                showResignConfirm = false,
                gameStatus = GameStatus.RESIGNED
            )
        }
    }

    fun requestDraw() {
        val state = _uiState.value
        if (state.gameStatus.isGameOver) return

        if (state.gameMode == GameMode.LOCAL_FRIEND) {
            _uiState.update { it.copy(showDrawOfferConfirm = true) }
        } else {
            // AI evaluation for draw offer: if evaluation is roughly even (-75 to +75 centipawns), accept!
            val eval = ChessEngineAi.evaluateBoard(state.board, PieceColor.WHITE)
            if (kotlin.math.abs(eval) < 90) {
                clockJob?.cancel()
                feedback.playGameOver(state.soundEnabled, state.hapticsEnabled)
                _uiState.update {
                    it.copy(
                        gameStatus = GameStatus.DRAW_AGREED,
                        statusMessage = "AI accepts your draw offer."
                    )
                }
            } else {
                _uiState.update {
                    it.copy(statusMessage = "AI declines the draw offer. The game continues.")
                }
                viewModelScope.launch {
                    delay(3000)
                    _uiState.update { it.copy(statusMessage = null) }
                }
            }
        }
    }

    fun acceptDraw() {
        clockJob?.cancel()
        feedback.playGameOver(_uiState.value.soundEnabled, _uiState.value.hapticsEnabled)
        _uiState.update {
            it.copy(
                showDrawOfferConfirm = false,
                gameStatus = GameStatus.DRAW_AGREED
            )
        }
    }

    fun declineDraw() {
        _uiState.update { it.copy(showDrawOfferConfirm = false) }
    }

    private fun startClockTicker() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val state = _uiState.value
                if (state.gameStatus.isGameOver || !state.isTimerActive) continue

                val isWhiteTurn = state.board.activeColor == PieceColor.WHITE
                if (isWhiteTurn) {
                    val remaining = state.whiteTimeSeconds - 1
                    if (remaining <= 0) {
                        clockJob?.cancel()
                        feedback.playGameOver(state.soundEnabled, state.hapticsEnabled)
                        _uiState.update {
                            it.copy(
                                whiteTimeSeconds = 0,
                                gameStatus = GameStatus.TIMEOUT,
                                statusMessage = "White ran out of time. Black wins!"
                            )
                        }
                    } else {
                        _uiState.update { it.copy(whiteTimeSeconds = remaining) }
                    }
                } else {
                    val remaining = state.blackTimeSeconds - 1
                    if (remaining <= 0) {
                        clockJob?.cancel()
                        feedback.playGameOver(state.soundEnabled, state.hapticsEnabled)
                        _uiState.update {
                            it.copy(
                                blackTimeSeconds = 0,
                                gameStatus = GameStatus.TIMEOUT,
                                statusMessage = "Black ran out of time. White wins!"
                            )
                        }
                    } else {
                        _uiState.update { it.copy(blackTimeSeconds = remaining) }
                    }
                }
            }
        }
    }

    // Settings modifiers
    fun setSoundEnabled(enabled: Boolean) {
        prefs.soundEnabled = enabled
        _uiState.update { it.copy(soundEnabled = enabled) }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.hapticsEnabled = enabled
        _uiState.update { it.copy(hapticsEnabled = enabled) }
    }

    fun setShowCoordinates(show: Boolean) {
        prefs.showCoordinates = show
        _uiState.update { it.copy(showCoordinates = show) }
    }

    fun setShowLegalMoves(show: Boolean) {
        prefs.showLegalMoves = show
        _uiState.update { it.copy(showLegalMoves = show) }
    }

    fun setMoveAnimation(enabled: Boolean) {
        prefs.moveAnimation = enabled
        _uiState.update { it.copy(moveAnimation = enabled) }
    }

    fun setConfirmResignation(confirm: Boolean) {
        prefs.confirmResignation = confirm
        _uiState.update { it.copy(confirmResignation = confirm) }
    }

    fun setAutoFlipBoard(autoFlip: Boolean) {
        prefs.autoFlipBoard = autoFlip
        _uiState.update { it.copy(autoFlipBoard = autoFlip) }
    }

    override fun onCleared() {
        super.onCleared()
        clockJob?.cancel()
        aiJob?.cancel()
    }
}
