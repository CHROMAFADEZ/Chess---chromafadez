package com.example.chess.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.engine.ChessBoard
import com.example.chess.model.BoardTheme
import com.example.chess.model.GameStatus
import com.example.chess.model.Move
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.pieces.ChessPieceRenderer

@Composable
fun ChessBoardView(
    board: ChessBoard,
    theme: BoardTheme,
    selectedSquare: Square?,
    legalTargets: List<Square>,
    lastMove: Move?,
    gameStatus: GameStatus,
    isFlipped: Boolean,
    showCoordinates: Boolean,
    showLegalMoves: Boolean,
    onSquareClicked: (Square) -> Unit,
    modifier: Modifier = Modifier,
    pieceStyle: com.example.chess.model.PieceStyle = com.example.chess.model.PieceStyle.STAUNTON
) {
    // Find King in check square if applicable
    val inCheckKingSquare = if (gameStatus == GameStatus.CHECK || gameStatus == GameStatus.CHECKMATE) {
        board.getKingSquare(board.activeColor)
    } else null

    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .border(2.dp, theme.boardBorder, RoundedCornerShape(6.dp))
            .background(theme.boardBorder)
    ) {
        val squareSize = maxWidth / 8

        Column(modifier = Modifier.fillMaxSize()) {
            val rankRange = if (isFlipped) (0..7) else (7 downTo 0)
            val fileRange = if (isFlipped) (7 downTo 0) else (0..7)

            for (rank in rankRange) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    for (file in fileRange) {
                        val square = Square(file, rank)
                        val piece = board.getPiece(square)
                        val isLight = square.isLightSquare
                        val isSelected = square == selectedSquare
                        val isLastMoveFrom = lastMove?.from == square
                        val isLastMoveTo = lastMove?.to == square
                        val isLegalTarget = showLegalMoves && legalTargets.contains(square)
                        val isKingInCheck = inCheckKingSquare == square

                        // Base square color
                        val baseColor = if (isLight) theme.lightSquare else theme.darkSquare
                        val squareBgColor = when {
                            isKingInCheck -> theme.checkSquare
                            isSelected -> theme.selectedSquare
                            isLastMoveTo || isLastMoveFrom -> if (isLight) theme.lastMoveLight else theme.lastMoveDark
                            else -> baseColor
                        }

                        val interactionSource = remember { MutableInteractionSource() }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .background(squareBgColor)
                                .testTag("square_${square.algebraic}")
                                .clickable(
                                    interactionSource = interactionSource,
                                    indication = null
                                ) {
                                    onSquareClicked(square)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            // Coordinate labels
                            if (showCoordinates) {
                                val coordColor = if (isLight) theme.coordinateTextLight else theme.coordinateTextDark

                                // Rank label on leftmost column
                                val isFirstCol = if (isFlipped) file == 7 else file == 0
                                if (isFirstCol) {
                                    Text(
                                        text = "${rank + 1}",
                                        color = coordColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(start = 3.dp, top = 2.dp)
                                    )
                                }

                                // File label on bottommost row
                                val isLastRow = if (isFlipped) rank == 7 else rank == 0
                                if (isLastRow) {
                                    Text(
                                        text = "${'a' + file}",
                                        color = coordColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(end = 3.dp, bottom = 2.dp)
                                    )
                                }
                            }

                            // Render piece
                            if (piece != null) {
                                ChessPieceRenderer.RenderPiece(
                                    piece = piece,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(4.dp),
                                    style = pieceStyle
                                )
                            }

                            // Legal move indicator overlay
                            if (isLegalTarget) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val isCapture = piece != null || (
                                            board.enPassantTarget == square &&
                                                    board.getPiece(selectedSquare ?: square)?.type == PieceType.PAWN
                                            )
                                    if (isCapture) {
                                        // Capture indicator: ring around perimeter
                                        drawCircle(
                                            color = theme.legalMoveDot,
                                            radius = size.minDimension * 0.44f,
                                            style = Stroke(width = size.minDimension * 0.08f)
                                        )
                                    } else {
                                        // Move indicator: centered solid dot
                                        drawCircle(
                                            color = theme.legalMoveDot,
                                            radius = size.minDimension * 0.16f
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
