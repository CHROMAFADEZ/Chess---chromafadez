package com.example.chess.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessWarmWhite

/**
 * Authentic Staunton Tournament Chess Knight Logo.
 * A single solid dark charcoal silhouette featuring clearly defined equine anatomy:
 * - Upright pointed horse ears
 * - Arched, crested neck with carved mane
 * - Distinct muzzle, nostril, and jawline
 * - Classic chess piece pedestal base
 */
@Composable
fun ChessKnightLogo(
    modifier: Modifier = Modifier,
    sizeDp: Dp = 56.dp,
    tint: Color = ChessCharcoal,
    detailColor: Color = ChessWarmWhite
) {
    Box(
        modifier = modifier.size(sizeDp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val w = size.width
            val h = size.height

            // Helper function to scale normalized (0..100) coordinates to canvas dimensions
            fun x(valX: Float): Float = (valX / 100f) * w
            fun y(valY: Float): Float = (valY / 100f) * h

            // 1. Pedestal Base Silhouette
            val basePath = Path().apply {
                // Tier 1 (bottom-most weighted disc)
                moveTo(x(16f), y(93f))
                lineTo(x(84f), y(93f))
                lineTo(x(82f), y(87f))
                lineTo(x(18f), y(87f))
                close()

                // Tier 2 (tapered pedestal collar)
                moveTo(x(22f), y(86f))
                lineTo(x(78f), y(86f))
                lineTo(x(73f), y(80f))
                lineTo(x(27f), y(80f))
                close()
            }
            drawPath(basePath, color = tint, style = Fill)

            // 2. Horse Body Silhouette (Staunton Knight in 3/4 profile facing left)
            val knightBody = Path().apply {
                // Start at front chest above the collar
                moveTo(x(30f), y(80f))

                // Throat curves gently upward
                cubicTo(
                    x(36f), y(68f),
                    x(37f), y(58f),
                    x(33f), y(51f)
                )

                // Under jaw to chin
                lineTo(x(25f), y(48.5f))

                // Chin / Muzzle tip
                cubicTo(
                    x(18f), y(46f),
                    x(16f), y(42f),
                    x(17.5f), y(38f)
                )

                // Snout / Bridge of the nose
                lineTo(x(25f), y(27f))

                // Forehead to base of front ear
                cubicTo(
                    x(28f), y(23f),
                    x(31f), y(21f),
                    x(33.5f), y(19f)
                )

                // Front Ear (straight, pointed horse ear angled slightly forward)
                lineTo(x(35.5f), y(8f))
                lineTo(x(40f), y(15.5f))

                // Back Ear notch & tip (giving 3/4 Staunton horse dimension)
                lineTo(x(44.5f), y(10f))
                lineTo(x(47f), y(17f))

                // Majestic arched crest of the mane
                cubicTo(
                    x(57f), y(21f),
                    x(69f), y(30f),
                    x(73f), y(42f)
                )

                // Down the curved neck to the rear shoulder
                cubicTo(
                    x(74f), y(54f),
                    x(72f), y(68f),
                    x(67f), y(80f)
                )

                // Base of neck
                lineTo(x(30f), y(80f))
                close()
            }
            drawPath(knightBody, color = tint, style = Fill)

            // 3. Delicate Carved Staunton Features (Negative space line cuts)
            val strokeW = w * 0.024f

            // Eye: Almond-shaped equine eye
            drawCircle(
                color = detailColor,
                radius = w * 0.026f,
                center = Offset(x(31f), y(29f))
            )

            // Nostril slit
            drawLine(
                color = detailColor,
                start = Offset(x(20f), y(41f)),
                end = Offset(x(23f), y(42.5f)),
                strokeWidth = strokeW * 1.1f,
                cap = StrokeCap.Round
            )

            // Mouth line
            drawLine(
                color = detailColor,
                start = Offset(x(18f), y(44.5f)),
                end = Offset(x(25f), y(45.5f)),
                strokeWidth = strokeW,
                cap = StrokeCap.Round
            )

            // Jaw / Cheek muscle curve
            val jawPath = Path().apply {
                moveTo(x(33f), y(48f))
                quadraticTo(x(36f), y(42f), x(33f), y(36f))
            }
            drawPath(jawPath, color = detailColor, style = Stroke(strokeW, cap = StrokeCap.Round))

            // Mane tufts / carved scallops along the crest
            val maneTuft1 = Path().apply {
                moveTo(x(52f), y(25f))
                quadraticTo(x(47f), y(31f), x(45f), y(37f))
            }
            drawPath(maneTuft1, color = detailColor, style = Stroke(strokeW * 0.9f, cap = StrokeCap.Round))

            val maneTuft2 = Path().apply {
                moveTo(x(62f), y(36f))
                quadraticTo(x(56f), y(43f), x(54f), y(51f))
            }
            drawPath(maneTuft2, color = detailColor, style = Stroke(strokeW * 0.9f, cap = StrokeCap.Round))

            val maneTuft3 = Path().apply {
                moveTo(x(65f), y(52f))
                quadraticTo(x(60f), y(59f), x(58f), y(67f))
            }
            drawPath(maneTuft3, color = detailColor, style = Stroke(strokeW * 0.9f, cap = StrokeCap.Round))

            // Base separation accent line
            drawLine(
                color = detailColor,
                start = Offset(x(24f), y(86.5f)),
                end = Offset(x(76f), y(86.5f)),
                strokeWidth = strokeW * 0.8f,
                cap = StrokeCap.Round
            )
        }
    }
}
