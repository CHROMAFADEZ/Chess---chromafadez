package com.example.chess.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.GameStatus
import com.example.chess.model.PieceColor
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessSurface
import com.example.chess.ui.theme.ChessWalnut
import com.example.chess.ui.theme.ChessWarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameOverDialog(
    status: GameStatus,
    activeColor: PieceColor,
    statusMessage: String?,
    onRematch: () -> Unit,
    onNewGame: () -> Unit,
    onReturnHome: () -> Unit
) {
    val winnerText = when (status) {
        GameStatus.CHECKMATE -> {
            val winner = activeColor.opponent()
            if (winner == PieceColor.WHITE) "White wins by checkmate" else "Black wins by checkmate"
        }
        GameStatus.STALEMATE -> "Draw by stalemate"
        GameStatus.DRAW_INSUFFICIENT_MATERIAL -> "Draw by insufficient material"
        GameStatus.DRAW_FIFTY_MOVES -> "Draw by 50-move rule"
        GameStatus.DRAW_THREEFOLD -> "Draw by threefold repetition"
        GameStatus.DRAW_AGREED -> "Draw agreed by players"
        GameStatus.RESIGNED -> {
            val winner = activeColor.opponent()
            if (winner == PieceColor.WHITE) "White wins by resignation" else "Black wins by resignation"
        }
        GameStatus.TIMEOUT -> {
            statusMessage ?: "Game won on time"
        }
        else -> ""
    }

    val headerText = when (status) {
        GameStatus.CHECKMATE -> "CHECKMATE"
        GameStatus.STALEMATE -> "STALEMATE"
        GameStatus.RESIGNED -> "RESIGNATION"
        GameStatus.TIMEOUT -> "TIME OUT"
        else -> "DRAW"
    }

    BasicAlertDialog(
        onDismissRequest = { /* Modal persists until user chooses action */ }
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(ChessSurface)
                .border(1.dp, ChessBorder, RoundedCornerShape(12.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = headerText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = ChessCharcoal,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = winnerText,
                    fontSize = 14.sp,
                    color = ChessCharcoalMuted,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Primary Action: Rematch
                Button(
                    onClick = onRematch,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ChessWalnut,
                        contentColor = ChessWarmWhite
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("game_over_rematch_button")
                ) {
                    Text(
                        text = "Rematch",
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Action: New Game / Options
                OutlinedButton(
                    onClick = onNewGame,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = ChessCharcoal
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("game_over_new_game_button")
                ) {
                    Text(
                        text = "New Game",
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Return Home
                OutlinedButton(
                    onClick = onReturnHome,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = ChessCharcoalMuted
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("game_over_home_button")
                ) {
                    Text(
                        text = "Return Home",
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }
    }
}
