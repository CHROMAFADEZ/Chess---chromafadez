package com.example.chess.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.Move
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessSoftIvory
import com.example.chess.ui.theme.ChessWalnut

@Composable
fun MoveHistoryView(
    moves: List<Move>,
    modifier: Modifier = Modifier,
    maxHeightDp: Int = 110
) {
    val listState = rememberLazyListState()
    val pairs = moves.chunked(2)

    // Auto-scroll to end on new moves
    LaunchedEffect(moves.size) {
        if (pairs.isNotEmpty()) {
            listState.animateScrollToItem(pairs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(ChessSoftIvory.copy(alpha = 0.35f))
            .border(0.5.dp, ChessBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // Section Header: MOVE HISTORY
        Text(
            text = "MOVE HISTORY",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = ChessCharcoalMuted,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        if (moves.isEmpty()) {
            Text(
                text = "Game in progress — no moves yet",
                fontSize = 12.sp,
                color = ChessCharcoalMuted,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeightDp.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                itemsIndexed(pairs) { index, pair ->
                    val moveNumber = index + 1
                    val whiteMove = pair.getOrNull(0)
                    val blackMove = pair.getOrNull(1)
                    val isWhiteLast = whiteMove != null && whiteMove == moves.lastOrNull()
                    val isBlackLast = blackMove != null && blackMove == moves.lastOrNull()

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 1.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Move Number (e.g. "1.")
                        Text(
                            text = "$moveNumber.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            color = ChessCharcoalMuted,
                            modifier = Modifier.width(28.dp)
                        )

                        // White Move
                        if (whiteMove != null) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isWhiteLast) ChessCream else Color.Transparent)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = whiteMove.san.ifEmpty { whiteMove.toUci() },
                                    fontSize = 13.sp,
                                    fontWeight = if (isWhiteLast) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isWhiteLast) ChessWalnut else ChessCharcoal
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }

                        // Black Move
                        if (blackMove != null) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isBlackLast) ChessCream else Color.Transparent)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = blackMove.san.ifEmpty { blackMove.toUci() },
                                    fontSize = 13.sp,
                                    fontWeight = if (isBlackLast) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isBlackLast) ChessWalnut else ChessCharcoal
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
