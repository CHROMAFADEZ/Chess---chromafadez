package com.example.chess.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceStyle
import com.example.chess.model.PieceType
import com.example.chess.pieces.ChessPieceRenderer
import com.example.chess.ui.theme.ChessAlertRed
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessWalnut

@Composable
fun PlayerInfoCard(
    name: String,
    subtitle: String? = null,
    color: PieceColor,
    isCurrentTurn: Boolean,
    timeSeconds: Int,
    isTimerUnlimited: Boolean,
    capturedPieces: List<Piece>,
    materialAdvantage: Int,
    isAiThinking: Boolean = false,
    pieceStyle: PieceStyle = PieceStyle.STAUNTON,
    modifier: Modifier = Modifier
) {
    val isLowTime = !isTimerUnlimited && timeSeconds <= 30 && isCurrentTurn

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        // Top line: Name, Turn status, and Timer
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Player title + turn indicator + subtitle
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Subtle active-turn dot
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isCurrentTurn) ChessWalnut else Color.Transparent)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = name,
                    fontSize = 14.sp,
                    fontWeight = if (isCurrentTurn) FontWeight.SemiBold else FontWeight.Normal,
                    color = ChessCharcoal,
                    letterSpacing = 0.25.sp
                )

                if (!subtitle.isNullOrBlank()) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• $subtitle",
                        fontSize = 12.sp,
                        color = ChessCharcoalMuted
                    )
                }

                if (isAiThinking) {
                    Spacer(modifier = Modifier.width(8.dp))
                    CircularProgressIndicator(
                        modifier = Modifier.size(10.dp),
                        strokeWidth = 1.5.dp,
                        color = ChessWalnut
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "thinking…",
                        fontSize = 11.sp,
                        color = ChessCharcoalMuted,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }

            // Minimalist Timer
            if (!isTimerUnlimited) {
                val minutes = timeSeconds / 60
                val seconds = timeSeconds % 60
                val formattedTime = String.format("%02d:%02d", minutes, seconds)

                Text(
                    text = formattedTime,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isCurrentTurn) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 14.sp,
                    color = if (isLowTime) ChessAlertRed else if (isCurrentTurn) ChessCharcoal else ChessCharcoalMuted,
                    modifier = Modifier.testTag("clock_${color.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        // Bottom line: Captured pieces & material advantage
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (capturedPieces.isNotEmpty()) {
                val grouped = capturedPieces.groupBy { it.type }
                val sortedTypes = listOf(
                    PieceType.PAWN,
                    PieceType.KNIGHT,
                    PieceType.BISHOP,
                    PieceType.ROOK,
                    PieceType.QUEEN
                )

                for (t in sortedTypes) {
                    val count = grouped[t]?.size ?: 0
                    if (count > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Box(modifier = Modifier.size(14.dp)) {
                                ChessPieceRenderer.RenderPiece(
                                    piece = Piece(t, color.opponent()),
                                    modifier = Modifier.fillMaxWidth(),
                                    style = pieceStyle
                                )
                            }
                            if (count > 1) {
                                Text(
                                    text = "$count",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = ChessCharcoalMuted
                                )
                            }
                        }
                    }
                }
            }

            if (materialAdvantage > 0) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "+$materialAdvantage",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = ChessWalnut
                )
            }
        }
    }
}
