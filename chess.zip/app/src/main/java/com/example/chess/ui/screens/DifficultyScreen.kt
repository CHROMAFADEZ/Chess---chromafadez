package com.example.chess.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.AiDifficulty
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessWalnut
import com.example.chess.ui.theme.ChessWarmWhite

@Composable
fun DifficultyScreen(
    currentDifficulty: AiDifficulty,
    onDifficultySelected: (AiDifficulty) -> Unit,
    onStartGame: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ChessWarmWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
    ) {
        // Navigation header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("difficulty_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = ChessCharcoal
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "CHOOSE YOUR OPPONENT",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                color = ChessCharcoal
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 10 AI Levels list: strictly "01 — Beginner" to "10 — Legend" with no rating/ELO info
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(AiDifficulty.ALL) { difficulty ->
                val isSelected = difficulty.level == currentDifficulty.level

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) ChessCream else Color.Transparent)
                        .border(
                            width = if (isSelected) 1.dp else 0.5.dp,
                            color = if (isSelected) ChessWalnut else ChessBorder.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onDifficultySelected(difficulty) }
                        .padding(horizontal = 16.dp, vertical = 13.dp)
                        .testTag("difficulty_level_${difficulty.level}"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${difficulty.formattedNumber} — ${difficulty.name}",
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            fontFamily = FontFamily.Default,
                            color = if (isSelected) ChessWalnut else ChessCharcoal,
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Subtle, understated selection indicator dot
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(ChessWalnut)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Start Game Button
        Button(
            onClick = onStartGame,
            colors = ButtonDefaults.buttonColors(
                containerColor = ChessWalnut,
                contentColor = ChessWarmWhite
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("difficulty_start_game_button")
        ) {
            Text(
                text = "START GAME",
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
