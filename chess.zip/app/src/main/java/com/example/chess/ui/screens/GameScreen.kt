package com.example.chess.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.GameMode
import com.example.chess.model.GameStatus
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import com.example.chess.ui.ChessUiState
import com.example.chess.ui.components.ChessBoardView
import com.example.chess.ui.components.GameOverDialog
import com.example.chess.ui.components.MoveHistoryView
import com.example.chess.ui.components.PlayerInfoCard
import com.example.chess.ui.components.PromotionDialog
import com.example.chess.ui.theme.ChessAlertRed
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessSoftIvory
import com.example.chess.ui.theme.ChessSurface
import com.example.chess.ui.theme.ChessWalnut
import com.example.chess.ui.theme.ChessWarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    state: ChessUiState,
    onSquareClicked: (Square) -> Unit,
    onPromotionPieceSelected: (PieceType) -> Unit,
    onDismissPromotionDialog: () -> Unit,
    onUndo: () -> Unit,
    onRequestDraw: () -> Unit,
    onRequestResign: () -> Unit,
    onConfirmResign: () -> Unit,
    onCancelResign: () -> Unit,
    onAcceptDraw: () -> Unit,
    onDeclineDraw: () -> Unit,
    onToggleFlip: () -> Unit,
    onOpenSettings: () -> Unit,
    onRematch: () -> Unit,
    onNewGame: () -> Unit,
    onReturnHome: () -> Unit
) {
    var showExitDialog by remember { mutableStateOf(false) }

    BackHandler {
        if (!state.gameStatus.isGameOver) {
            showExitDialog = true
        } else {
            onReturnHome()
        }
    }

    val isWhiteAtBottom = !state.isBoardFlipped
    val topColor = if (isWhiteAtBottom) PieceColor.BLACK else PieceColor.WHITE
    val bottomColor = if (isWhiteAtBottom) PieceColor.WHITE else PieceColor.BLACK

    val topName: String
    val topSubtitle: String?
    val bottomName: String
    val bottomSubtitle: String?

    if (state.gameMode == GameMode.VS_AI) {
        if (topColor == PieceColor.BLACK) {
            topName = "AI"
            topSubtitle = "Level ${state.difficulty.level} — ${state.difficulty.name}"
            bottomName = "You"
            bottomSubtitle = null
        } else {
            topName = "You"
            topSubtitle = null
            bottomName = "AI"
            bottomSubtitle = "Level ${state.difficulty.level} — ${state.difficulty.name}"
        }
    } else {
        topName = if (topColor == PieceColor.WHITE) "White" else "Black"
        topSubtitle = if (topColor == PieceColor.BLACK) "Player 2" else "Player 1"
        bottomName = if (bottomColor == PieceColor.WHITE) "White" else "Black"
        bottomSubtitle = if (bottomColor == PieceColor.WHITE) "Player 1" else "Player 2"
    }

    val capturedByTop = if (topColor == PieceColor.WHITE) state.board.getCapturedByWhite() else state.board.getCapturedByBlack()
    val capturedByBottom = if (bottomColor == PieceColor.WHITE) state.board.getCapturedByWhite() else state.board.getCapturedByBlack()

    val matAdvantage = state.board.getMaterialAdvantage()
    val topMatAdvantage = if (topColor == PieceColor.WHITE) matAdvantage.coerceAtLeast(0) else (-matAdvantage).coerceAtLeast(0)
    val bottomMatAdvantage = if (bottomColor == PieceColor.WHITE) matAdvantage.coerceAtLeast(0) else (-matAdvantage).coerceAtLeast(0)

    val topTime = if (topColor == PieceColor.WHITE) state.whiteTimeSeconds else state.blackTimeSeconds
    val bottomTime = if (bottomColor == PieceColor.WHITE) state.whiteTimeSeconds else state.blackTimeSeconds

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ChessWarmWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        val isWide = maxWidth >= 720.dp

        if (isWide) {
            // Desktop / Wide Layout: Board strictly centered, side column for move history & controls
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Centered Board Area
                Column(
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .weight(1f, fill = false),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Player Info
                    PlayerInfoCard(
                        name = topName,
                        subtitle = topSubtitle,
                        color = topColor,
                        isCurrentTurn = state.board.activeColor == topColor && !state.gameStatus.isGameOver,
                        timeSeconds = topTime,
                        isTimerUnlimited = state.timeControl.isUnlimited,
                        capturedPieces = capturedByTop,
                        materialAdvantage = topMatAdvantage,
                        isAiThinking = state.isAiThinking && topColor == PieceColor.BLACK,
                        pieceStyle = state.pieceStyle
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // The Chessboard
                    ChessBoardView(
                        board = state.board,
                        theme = state.theme,
                        selectedSquare = state.selectedSquare,
                        legalTargets = state.legalTargetSquares,
                        lastMove = state.lastMove,
                        gameStatus = state.gameStatus,
                        isFlipped = state.isBoardFlipped,
                        showCoordinates = state.showCoordinates,
                        showLegalMoves = state.showLegalMoves,
                        onSquareClicked = onSquareClicked,
                        pieceStyle = state.pieceStyle,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Bottom Player Info
                    PlayerInfoCard(
                        name = bottomName,
                        subtitle = bottomSubtitle,
                        color = bottomColor,
                        isCurrentTurn = state.board.activeColor == bottomColor && !state.gameStatus.isGameOver,
                        timeSeconds = bottomTime,
                        isTimerUnlimited = state.timeControl.isUnlimited,
                        capturedPieces = capturedByBottom,
                        materialAdvantage = bottomMatAdvantage,
                        isAiThinking = state.isAiThinking && bottomColor == PieceColor.BLACK,
                        pieceStyle = state.pieceStyle
                    )
                }

                Spacer(modifier = Modifier.width(32.dp))

                // Side Area: Navigation header, Move History, and Controls
                Column(
                    modifier = Modifier
                        .width(280.dp)
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (!state.gameStatus.isGameOver) showExitDialog = true else onReturnHome()
                                },
                                modifier = Modifier.testTag("game_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Leave Game",
                                    tint = ChessCharcoal
                                )
                            }

                            Text(
                                text = when (state.gameStatus) {
                                    GameStatus.CHECK -> "CHECK"
                                    GameStatus.CHECKMATE -> "CHECKMATE"
                                    GameStatus.STALEMATE -> "STALEMATE"
                                    GameStatus.TIMEOUT -> "TIME OUT"
                                    GameStatus.RESIGNED -> "RESIGNED"
                                    GameStatus.DRAW_AGREED, GameStatus.DRAW_FIFTY_MOVES, GameStatus.DRAW_INSUFFICIENT_MATERIAL, GameStatus.DRAW_THREEFOLD -> "DRAW"
                                    else -> if (state.board.activeColor == PieceColor.WHITE) "White's turn" else "Black's turn"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.sp,
                                color = if (state.gameStatus == GameStatus.CHECK) ChessAlertRed else ChessCharcoalMuted
                            )

                            IconButton(
                                onClick = onOpenSettings,
                                modifier = Modifier.testTag("game_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Settings,
                                    contentDescription = "Settings",
                                    tint = ChessCharcoalMuted
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Move History
                        MoveHistoryView(
                            moves = state.board.getMoveHistory(),
                            modifier = Modifier.fillMaxWidth(),
                            maxHeightDp = 260
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Controls
                    GameControlsBar(
                        state = state,
                        onUndo = onUndo,
                        onRequestDraw = onRequestDraw,
                        onRequestResign = onRequestResign,
                        onToggleFlip = onToggleFlip,
                        onOpenSettings = onOpenSettings
                    )
                }
            }
        } else {
            // Mobile Layout: Centered board as large as practical, reflowing naturally
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (!state.gameStatus.isGameOver) showExitDialog = true else onReturnHome()
                        },
                        modifier = Modifier.testTag("game_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Leave Game",
                            tint = ChessCharcoal
                        )
                    }

                    Text(
                        text = when (state.gameStatus) {
                            GameStatus.CHECK -> "CHECK"
                            GameStatus.CHECKMATE -> "CHECKMATE"
                            GameStatus.STALEMATE -> "STALEMATE"
                            GameStatus.TIMEOUT -> "TIME OUT"
                            GameStatus.RESIGNED -> "RESIGNED"
                            GameStatus.DRAW_AGREED, GameStatus.DRAW_FIFTY_MOVES, GameStatus.DRAW_INSUFFICIENT_MATERIAL, GameStatus.DRAW_THREEFOLD -> "DRAW"
                            else -> if (state.board.activeColor == PieceColor.WHITE) "White's turn" else "Black's turn"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = if (state.gameStatus == GameStatus.CHECK) ChessAlertRed else ChessCharcoalMuted
                    )

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("game_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Settings",
                            tint = ChessCharcoalMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Top Player Info
                PlayerInfoCard(
                    name = topName,
                    subtitle = topSubtitle,
                    color = topColor,
                    isCurrentTurn = state.board.activeColor == topColor && !state.gameStatus.isGameOver,
                    timeSeconds = topTime,
                    isTimerUnlimited = state.timeControl.isUnlimited,
                    capturedPieces = capturedByTop,
                    materialAdvantage = topMatAdvantage,
                    isAiThinking = state.isAiThinking && topColor == PieceColor.BLACK,
                    pieceStyle = state.pieceStyle,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                // The Centerpiece: Chessboard
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ChessBoardView(
                        board = state.board,
                        theme = state.theme,
                        selectedSquare = state.selectedSquare,
                        legalTargets = state.legalTargetSquares,
                        lastMove = state.lastMove,
                        gameStatus = state.gameStatus,
                        isFlipped = state.isBoardFlipped,
                        showCoordinates = state.showCoordinates,
                        showLegalMoves = state.showLegalMoves,
                        onSquareClicked = onSquareClicked,
                        pieceStyle = state.pieceStyle,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Bottom Player Info
                PlayerInfoCard(
                    name = bottomName,
                    subtitle = bottomSubtitle,
                    color = bottomColor,
                    isCurrentTurn = state.board.activeColor == bottomColor && !state.gameStatus.isGameOver,
                    timeSeconds = bottomTime,
                    isTimerUnlimited = state.timeControl.isUnlimited,
                    capturedPieces = capturedByBottom,
                    materialAdvantage = bottomMatAdvantage,
                    isAiThinking = state.isAiThinking && bottomColor == PieceColor.BLACK,
                    pieceStyle = state.pieceStyle,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Move History Area
                MoveHistoryView(
                    moves = state.board.getMoveHistory(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp),
                    maxHeightDp = 90
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Game Controls
                GameControlsBar(
                    state = state,
                    onUndo = onUndo,
                    onRequestDraw = onRequestDraw,
                    onRequestResign = onRequestResign,
                    onToggleFlip = onToggleFlip,
                    onOpenSettings = onOpenSettings,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 460.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }

    // Pawn Promotion Dialog
    if (state.pendingPromotionFromTo != null) {
        val promoColor = state.board.activeColor
        PromotionDialog(
            color = promoColor,
            onPieceSelected = onPromotionPieceSelected,
            onDismiss = onDismissPromotionDialog
        )
    }

    // Game Over Dialog
    if (state.gameStatus.isGameOver) {
        GameOverDialog(
            status = state.gameStatus,
            activeColor = state.board.activeColor,
            statusMessage = state.statusMessage,
            onRematch = onRematch,
            onNewGame = onNewGame,
            onReturnHome = onReturnHome
        )
    }

    // Resign Confirmation Dialog
    if (state.showResignConfirm) {
        AlertDialog(
            onDismissRequest = onCancelResign,
            title = { Text("Resign Game", fontWeight = FontWeight.Bold, color = ChessCharcoal) },
            text = { Text("Are you sure you want to resign the game?", color = ChessCharcoalMuted) },
            confirmButton = {
                Button(
                    onClick = onConfirmResign,
                    colors = ButtonDefaults.buttonColors(containerColor = ChessAlertRed)
                ) {
                    Text("Resign")
                }
            },
            dismissButton = {
                TextButton(onClick = onCancelResign) {
                    Text("Cancel", color = ChessCharcoal)
                }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = ChessSurface
        )
    }

    // Draw Offer Dialog (for local 2-player mode)
    if (state.showDrawOfferConfirm) {
        AlertDialog(
            onDismissRequest = onDeclineDraw,
            title = { Text("Draw Offered", fontWeight = FontWeight.Bold, color = ChessCharcoal) },
            text = { Text("Your opponent is offering a draw. Do you accept?", color = ChessCharcoalMuted) },
            confirmButton = {
                Button(
                    onClick = onAcceptDraw,
                    colors = ButtonDefaults.buttonColors(containerColor = ChessWalnut)
                ) {
                    Text("Accept Draw")
                }
            },
            dismissButton = {
                TextButton(onClick = onDeclineDraw) {
                    Text("Decline", color = ChessCharcoal)
                }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = ChessSurface
        )
    }

    // Leave Game Confirmation
    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("Leave Game?", fontWeight = FontWeight.Bold, color = ChessCharcoal) },
            text = { Text("Are you sure you want to leave? Your current game will be discarded.", color = ChessCharcoalMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        showExitDialog = false
                        onReturnHome()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ChessWalnut)
                ) {
                    Text("Leave")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text("Keep Playing", color = ChessCharcoal)
                }
            },
            shape = RoundedCornerShape(12.dp),
            containerColor = ChessSurface
        )
    }
}

@Composable
private fun GameControlsBar(
    state: ChessUiState,
    onUndo: () -> Unit,
    onRequestDraw: () -> Unit,
    onRequestResign: () -> Unit,
    onToggleFlip: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Primary Controls Group: Undo, Draw, Resign
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Undo
            OutlinedButton(
                onClick = onUndo,
                enabled = state.board.getMoveHistory().isNotEmpty() && !state.isAiThinking && !state.gameStatus.isGameOver,
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChessCharcoal),
                modifier = Modifier.testTag("game_undo_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.Undo,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Undo", fontSize = 12.sp)
            }

            // Draw
            OutlinedButton(
                onClick = onRequestDraw,
                enabled = !state.gameStatus.isGameOver && !state.isAiThinking,
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChessCharcoal),
                modifier = Modifier.testTag("game_draw_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Handshake,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Draw", fontSize = 12.sp)
            }

            // Resign
            OutlinedButton(
                onClick = onRequestResign,
                enabled = !state.gameStatus.isGameOver && !state.isAiThinking,
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ChessAlertRed),
                modifier = Modifier.testTag("game_resign_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Flag,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp),
                    tint = ChessAlertRed
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Resign", fontSize = 12.sp, color = ChessAlertRed)
            }
        }

        // Secondary Controls Group: Flip, Settings
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleFlip,
                modifier = Modifier.testTag("game_flip_board_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.RotateRight,
                    contentDescription = "Flip Board",
                    tint = ChessCharcoalMuted
                )
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("game_controls_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Settings",
                    tint = ChessCharcoalMuted
                )
            }
        }
    }
}
