package com.example.chess.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.engine.ChessBoard
import com.example.chess.model.AiDifficulty
import com.example.chess.model.BoardTheme
import com.example.chess.model.GameMode
import com.example.chess.model.GameStatus
import com.example.chess.model.Square
import com.example.chess.model.TimeControl
import com.example.chess.ui.components.ChessBoardView
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessSoftIvory
import com.example.chess.ui.theme.ChessWalnut
import com.example.chess.ui.theme.ChessWarmWhite

@Composable
fun HomeScreen(
    selectedDifficulty: AiDifficulty,
    selectedTimeControl: TimeControl,
    selectedTheme: BoardTheme,
    selectedPieceStyle: com.example.chess.model.PieceStyle = com.example.chess.model.PieceStyle.STAUNTON,
    onPlayVsAi: () -> Unit,
    onPlayWithFriend: () -> Unit,
    onSelectDifficulty: () -> Unit,
    onOpenSettings: () -> Unit,
    onSelectTimeControl: (TimeControl) -> Unit,
    onSelectTheme: (BoardTheme) -> Unit
) {
    val previewBoard = remember { ChessBoard.createStartingBoard() }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ChessWarmWhite)
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Bar: Settings Icon
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag("home_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Settings",
                    tint = ChessCharcoalMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Single Unified Brand Identity: Knight Logo & CHESS
        com.example.chess.ui.components.ChessKnightLogo(sizeDp = 56.dp)

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "CHESS",
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 6.sp,
            color = ChessCharcoal,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = "Think ahead.",
            fontSize = 12.sp,
            letterSpacing = 1.sp,
            color = ChessCharcoalMuted,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Tasteful Chessboard Preview (compact)
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .fillMaxWidth(0.72f),
            contentAlignment = Alignment.Center
        ) {
            ChessBoardView(
                board = previewBoard,
                theme = selectedTheme,
                selectedSquare = null,
                legalTargets = emptyList(),
                lastMove = null,
                gameStatus = GameStatus.ACTIVE,
                isFlipped = false,
                showCoordinates = false,
                showLegalMoves = false,
                onSquareClicked = { /* preview only */ },
                pieceStyle = selectedPieceStyle
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Main Actions: PLAY VS AI & PLAY WITH FRIEND
        Column(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onPlayVsAi,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ChessWalnut,
                    contentColor = ChessWarmWhite
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("home_play_ai_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.SmartToy,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "PLAY VS AI",
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.5.sp,
                    fontSize = 13.sp
                )
            }

            OutlinedButton(
                onClick = onPlayWithFriend,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = ChessCharcoal
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .border(1.dp, ChessBorder, RoundedCornerShape(8.dp))
                    .testTag("home_play_friend_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Person,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = ChessCharcoal
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "PLAY WITH FRIEND",
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.5.sp,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Secondary Settings: Difficulty, Time Control, Theme
        Column(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Difficulty row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ChessSoftIvory.copy(alpha = 0.6f))
                    .border(1.dp, ChessBorder, RoundedCornerShape(8.dp))
                    .clickable { onSelectDifficulty() }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Difficulty",
                    fontSize = 13.sp,
                    color = ChessCharcoalMuted
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${selectedDifficulty.formattedNumber}  ${selectedDifficulty.name}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ChessCharcoal
                    )
                }
            }

            // Time Control selector row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ChessSoftIvory.copy(alpha = 0.6f))
                    .border(1.dp, ChessBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Time Control",
                    fontSize = 13.sp,
                    color = ChessCharcoalMuted
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val quickTimes = listOf(TimeControl.FIVE_MIN, TimeControl.TEN_MIN, TimeControl.UNLIMITED)
                    quickTimes.forEach { tc ->
                        val isSelected = selectedTimeControl.id == tc.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) ChessWalnut else Color.Transparent)
                                .clickable { onSelectTimeControl(tc) }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = tc.name,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) ChessWarmWhite else ChessCharcoal
                            )
                        }
                    }
                }
            }

            // Board Theme row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ChessSoftIvory.copy(alpha = 0.6f))
                    .border(1.dp, ChessBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Board Theme",
                    fontSize = 13.sp,
                    color = ChessCharcoalMuted
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BoardTheme.ALL.forEach { theme ->
                        val isSelected = selectedTheme.id == theme.id
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(theme.darkSquare)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) ChessWalnut else ChessBorder,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { onSelectTheme(theme) }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
