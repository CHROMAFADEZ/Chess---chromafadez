package com.example.chess.ui.screens

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.ui.components.ChessKnightLogo
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessWarmWhite

/**
 * Clips content symmetrically outward from the center horizontal axis
 * for a refined editorial center-origin reveal.
 */
private class CenterOutHorizontalClipShape(private val fraction: Float) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val f = fraction.coerceIn(0f, 1f)
        val halfVisibleWidth = (size.width * f) / 2f
        val centerX = size.width / 2f
        val left = (centerX - halfVisibleWidth).coerceAtLeast(0f)
        val right = (centerX + halfVisibleWidth).coerceAtMost(size.width)
        return Outline.Rectangle(Rect(left, 0f, right, size.height))
    }
}

@Composable
fun OpeningScreen(
    onAnimationFinished: () -> Unit
) {
    val context = LocalContext.current

    val isReducedMotion = remember {
        try {
            val scale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            )
            scale == 0f
        } catch (_: Exception) {
            false
        }
    }

    val progress = remember { Animatable(0f) }
    var hasFinished by remember { mutableStateOf(false) }

    // Total duration: 3200ms (~3.2s)
    LaunchedEffect(isReducedMotion) {
        if (isReducedMotion) {
            progress.snapTo(1f)
            kotlinx.coroutines.delay(600)
            if (!hasFinished) {
                hasFinished = true
                onAnimationFinished()
            }
        } else {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = 3200,
                    easing = LinearEasing
                )
            )
            if (!hasFinished) {
                hasFinished = true
                onAnimationFinished()
            }
        }
    }

    val p = progress.value

    // ================= Timeline Mapping (Total 3200ms) =================
    // 0.00 - 0.25s (0.000 to 0.078): Clean warm-white background already present.
    // 0.25 - 0.85s (0.078 to 0.265): Single Staunton Knight fades and scales into place.
    val knightEase = remember { CubicBezierEasing(0.25f, 0.1f, 0.25f, 1.0f) }
    val knightRaw = ((p - 0.078f) / 0.187f).coerceIn(0f, 1f)
    val knightProgress = knightEase.transform(knightRaw)
    val knightAlpha = knightProgress
    val knightScale = 0.95f + (0.05f * knightProgress)

    // 0.85 - 1.05s (0.265 to 0.328): Knight settles.
    // 1.00 - 1.10s (0.312 to 0.344): Central vertical cursor "|" fades in.
    val cursorIn = ((p - 0.312f) / 0.032f).coerceIn(0f, 1f)
    val cursorOut = ((p - 0.400f) / 0.120f).coerceIn(0f, 1f)
    val cursorAlpha = (cursorIn * (1f - cursorOut)).coerceIn(0f, 1f)

    // 1.05 - 1.65s (0.328 to 0.515): CHESS center-origin reveal
    val chessRaw = ((p - 0.328f) / 0.187f).coerceIn(0f, 1f)
    val chessEase = remember { CubicBezierEasing(0.2f, 0.0f, 0.2f, 1.0f) }
    val chessRevealProgress = chessEase.transform(chessRaw)

    // Comfortable letter spacing: eases smoothly from 3.5.sp to 6.sp
    val spacingRaw = ((p - 0.420f) / 0.150f).coerceIn(0f, 1f)
    val letterSpacingSp = 3.5f + (2.5f * spacingRaw)

    // 1.25 - 2.45s (0.390 to 0.765): CHROMAFADEZ slow, refined, readable type-on
    val creditFull = "CHROMAFADEZ"
    val creditRaw = ((p - 0.390f) / 0.375f).coerceIn(0f, 1f)
    val creditCharCount = (creditRaw * creditFull.length).toInt().coerceIn(0, creditFull.length)
    val typedCredit = creditFull.take(creditCharCount)
    val isCreditTyping = creditCharCount in 1 until creditFull.length

    // 2.45 - 2.85s (0.765 to 0.890): Breathing pause where all elements are fully visible and readable.
    // 2.85 - 3.20s (0.890 to 1.000): Smooth dissolve into home screen.
    val screenExitAlpha = if (p >= 0.890f) {
        (1f - ((p - 0.890f) / 0.110f)).coerceIn(0f, 1f)
    } else 1f

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ChessWarmWhite)
            .alpha(screenExitAlpha)
            .statusBarsPadding()
            .navigationBarsPadding()
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                // Responsive tap-to-skip
                if (!hasFinished) {
                    hasFinished = true
                    onAnimationFinished()
                }
            }
            .testTag("opening_splash_screen")
    ) {
        // ================= Center Identity =================
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. The Single Staunton Knight Logo (Solid dark charcoal tone)
            ChessKnightLogo(
                sizeDp = 56.dp,
                tint = ChessCharcoal,
                modifier = Modifier
                    .scale(knightScale)
                    .alpha(knightAlpha)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 2. "CHESS" Wordmark: Refined, smaller, center-origin masked reveal
            Box(
                modifier = Modifier
                    .height(28.dp)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Thin central vertical cursor "|"
                if (cursorAlpha > 0.01f && chessRevealProgress < 0.80f) {
                    Box(
                        modifier = Modifier
                            .width(1.2.dp)
                            .height(16.dp)
                            .alpha(cursorAlpha)
                            .background(ChessCharcoal)
                    )
                }

                // Symmetrical Center-Out Mask
                if (chessRevealProgress > 0.01f) {
                    Box(
                        modifier = Modifier
                            .clip(CenterOutHorizontalClipShape(chessRevealProgress))
                            .alpha(chessRevealProgress.coerceIn(0f, 1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CHESS",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = letterSpacingSp.sp,
                            color = ChessCharcoal,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // ================= Bottom-Right Owner Credit (ONLY "CHROMAFADEZ", NO C MARK) =================
        if (typedCredit.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 28.dp, bottom = 32.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = typedCredit,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                    color = ChessCharcoal.copy(alpha = 0.85f),
                    fontFamily = FontFamily.Default
                )

                // Subtle typing cursor (disappears as soon as full word settles)
                if (isCreditTyping) {
                    Spacer(modifier = Modifier.width(3.dp))
                    Box(
                        modifier = Modifier
                            .width(1.2.dp)
                            .height(13.dp)
                            .alpha(0.6f)
                            .background(ChessCharcoal.copy(alpha = 0.7f))
                    )
                }
            }
        }
    }
}
