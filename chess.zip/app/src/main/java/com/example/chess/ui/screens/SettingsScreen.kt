package com.example.chess.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chess.model.BoardTheme
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceStyle
import com.example.chess.model.PieceType
import com.example.chess.pieces.ChessPieceRenderer
import com.example.chess.ui.ChessUiState
import com.example.chess.ui.theme.ChessBorder
import com.example.chess.ui.theme.ChessCharcoal
import com.example.chess.ui.theme.ChessCharcoalMuted
import com.example.chess.ui.theme.ChessCream
import com.example.chess.ui.theme.ChessSoftIvory
import com.example.chess.ui.theme.ChessWalnut
import com.example.chess.ui.theme.ChessWarmWhite

@Composable
fun SettingsScreen(
    state: ChessUiState,
    onSoundChanged: (Boolean) -> Unit,
    onHapticsChanged: (Boolean) -> Unit,
    onCoordinatesChanged: (Boolean) -> Unit,
    onLegalMovesChanged: (Boolean) -> Unit,
    onMoveAnimationChanged: (Boolean) -> Unit,
    onConfirmResignChanged: (Boolean) -> Unit,
    onAutoFlipChanged: (Boolean) -> Unit,
    onThemeChanged: (BoardTheme) -> Unit,
    onPieceStyleChanged: (PieceStyle) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ChessWarmWhite)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
            .verticalScroll(scrollState)
    ) {
        // Navigation Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = ChessCharcoal
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Settings",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = ChessCharcoal
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ================= 1. BOARD =================
        SettingsSectionHeader(title = "BOARD")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ChessSoftIvory.copy(alpha = 0.45f))
                .border(0.5.dp, ChessBorder, RoundedCornerShape(8.dp))
        ) {
            BoardTheme.ALL.forEachIndexed { index, theme ->
                val isSelected = theme.id == state.theme.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onThemeChanged(theme) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("settings_theme_${theme.id}"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Light & dark square swatch
                        Row(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .border(1.dp, ChessBorder, RoundedCornerShape(4.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .background(theme.lightSquare)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .background(theme.darkSquare)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = theme.name,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            color = ChessCharcoal
                        )
                    }

                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(ChessWalnut)
                        )
                    }
                }

                if (index < BoardTheme.ALL.lastIndex) {
                    HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ================= 2. PIECES =================
        SettingsSectionHeader(title = "PIECES")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ChessSoftIvory.copy(alpha = 0.45f))
                .border(0.5.dp, ChessBorder, RoundedCornerShape(8.dp))
        ) {
            val pieceStyles = listOf(PieceStyle.CLASSIC, PieceStyle.STAUNTON, PieceStyle.MINIMAL)
            pieceStyles.forEachIndexed { index, pStyle ->
                val isSelected = pStyle == state.pieceStyle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPieceStyleChanged(pStyle) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("settings_piece_style_${pStyle.id}"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Live vector piece preview (Knight)
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(ChessCream)
                                .border(0.5.dp, ChessBorder, RoundedCornerShape(4.dp))
                                .padding(2.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            ChessPieceRenderer.RenderPiece(
                                piece = Piece(PieceType.KNIGHT, PieceColor.WHITE),
                                modifier = Modifier.fillMaxSize(),
                                style = pStyle
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = pStyle.displayName,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = ChessCharcoal
                            )
                            Text(
                                text = pStyle.description,
                                fontSize = 11.sp,
                                color = ChessCharcoalMuted
                            )
                        }
                    }

                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(ChessWalnut)
                        )
                    }
                }

                if (index < pieceStyles.lastIndex) {
                    HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ================= 3. GAME =================
        SettingsSectionHeader(title = "GAME")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ChessSoftIvory.copy(alpha = 0.45f))
                .border(0.5.dp, ChessBorder, RoundedCornerShape(8.dp))
        ) {
            // Show legal moves
            SettingsToggleRow(
                title = "Show legal moves",
                subtitle = "Subtle dots and rings for valid destinations",
                checked = state.showLegalMoves,
                onCheckedChange = onLegalMovesChanged,
                testTag = "settings_legal_moves_toggle"
            )
            HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            // Show coordinates
            SettingsToggleRow(
                title = "Show coordinates",
                subtitle = "Subtle rank (1-8) and file (a-h) edge labels",
                checked = state.showCoordinates,
                onCheckedChange = onCoordinatesChanged,
                testTag = "settings_coordinates_toggle"
            )
            HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            // Move animation
            SettingsToggleRow(
                title = "Move animation",
                subtitle = "Smooth and responsive visual movement",
                checked = state.moveAnimation,
                onCheckedChange = onMoveAnimationChanged,
                testTag = "settings_move_animation_toggle"
            )
            HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            // Sound
            SettingsToggleRow(
                title = "Sound",
                subtitle = "Clean audio cues for moves, captures, and check",
                checked = state.soundEnabled,
                onCheckedChange = onSoundChanged,
                testTag = "settings_sound_toggle"
            )
            HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            // Confirm resignation
            SettingsToggleRow(
                title = "Confirm resignation",
                subtitle = "Ask before conceding an active game",
                checked = state.confirmResignation,
                onCheckedChange = onConfirmResignChanged,
                testTag = "settings_confirm_resign_toggle"
            )
            HorizontalDivider(color = ChessBorder.copy(alpha = 0.4f), thickness = 0.5.dp)

            // Tactile haptics
            SettingsToggleRow(
                title = "Tactile haptics",
                subtitle = "Gentle vibration pulses on piece interaction",
                checked = state.hapticsEnabled,
                onCheckedChange = onHapticsChanged,
                testTag = "settings_haptics_toggle"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // ================= 4. APPEARANCE =================
        SettingsSectionHeader(title = "APPEARANCE")

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(ChessSoftIvory.copy(alpha = 0.35f))
                .border(0.5.dp, ChessBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Column {
                Text(
                    text = "Light & Professional Design",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = ChessCharcoal
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Crafted with warm ivory, soft cream, natural wood, and charcoal typography for timeless clarity.",
                    fontSize = 12.sp,
                    color = ChessCharcoalMuted,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = ChessCharcoalMuted,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = ChessCharcoal
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = ChessCharcoalMuted
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ChessWarmWhite,
                checkedTrackColor = ChessWalnut,
                uncheckedThumbColor = ChessCharcoalMuted,
                uncheckedTrackColor = ChessCream
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
