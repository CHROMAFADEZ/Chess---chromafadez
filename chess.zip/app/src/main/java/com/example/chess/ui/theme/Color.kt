package com.example.chess.ui.theme

import androidx.compose.ui.graphics.Color

// Light-first refined palette
val ChessWarmWhite = Color(0xFFFAF8F5)
val ChessCream = Color(0xFFF4EFE6)
val ChessSoftIvory = Color(0xFFEDE7DC)
val ChessSurface = Color(0xFFFFFFFF)
val ChessSurfaceVariant = Color(0xFFF5F1E9)

val ChessWalnut = Color(0xFF6B4E38)
val ChessWalnutDark = Color(0xFF4A3423)
val ChessWalnutLight = Color(0xFFB58863)

val ChessMutedGreen = Color(0xFF5A7540)
val ChessMutedGreenLight = Color(0xFF769656)

val ChessCharcoal = Color(0xFF22201D)
val ChessCharcoalMuted = Color(0xFF605C55)
val ChessBorder = Color(0xFFE2DCD2)
val ChessBorderDark = Color(0xFFC8BFB2)

val ChessAlertRed = Color(0xFFB33927)
val ChessCheckRed = Color(0xCCEB4D4B)
