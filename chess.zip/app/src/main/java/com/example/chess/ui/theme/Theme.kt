package com.example.chess.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val ChessTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Light,
        fontSize = 32.sp,
        letterSpacing = 4.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 20.sp,
        letterSpacing = 1.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 0.5.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.25.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.25.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 0.5.sp
    )
)

private val ChessColorScheme = lightColorScheme(
    primary = ChessWalnut,
    onPrimary = ChessWarmWhite,
    primaryContainer = ChessSoftIvory,
    onPrimaryContainer = ChessWalnutDark,
    secondary = ChessMutedGreen,
    onSecondary = ChessWarmWhite,
    secondaryContainer = ChessCream,
    onSecondaryContainer = ChessCharcoal,
    background = ChessWarmWhite,
    onBackground = ChessCharcoal,
    surface = ChessSurface,
    onSurface = ChessCharcoal,
    surfaceVariant = ChessSurfaceVariant,
    onSurfaceVariant = ChessCharcoalMuted,
    outline = ChessBorder,
    outlineVariant = ChessBorderDark,
    error = ChessAlertRed,
    onError = ChessWarmWhite
)

@Composable
fun ChessAppTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ChessColorScheme,
        typography = ChessTypography,
        content = content
    )
}
