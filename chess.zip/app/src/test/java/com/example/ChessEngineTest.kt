package com.example

import com.example.chess.ai.ChessEngineAi
import com.example.chess.engine.ChessBoard
import com.example.chess.model.AiDifficulty
import com.example.chess.model.GameStatus
import com.example.chess.model.Move
import com.example.chess.model.Piece
import com.example.chess.model.PieceColor
import com.example.chess.model.PieceType
import com.example.chess.model.Square
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChessEngineTest {

    @Test
    fun testStartingPositionLegalMoves() {
        val board = ChessBoard.createStartingBoard()
        val legalMoves = board.generateLegalMoves(PieceColor.WHITE)
        // 16 pawn moves (8 single + 8 double) + 4 knight moves (2 for each knight) = 20 moves
        assertEquals(20, legalMoves.size)
        assertEquals(GameStatus.ACTIVE, board.getGameStatus())
    }

    @Test
    fun testFirstMovesAndTurnToggle() {
        val board = ChessBoard.createStartingBoard()
        // 1. e4
        val e2 = Square.fromAlgebraic("e2")!!
        val e4 = Square.fromAlgebraic("e4")!!
        val move1 = Move(from = e2, to = e4)

        val success1 = board.makeMove(move1)
        assertTrue(success1)
        assertEquals(PieceColor.BLACK, board.activeColor)

        // 1... e5
        val e7 = Square.fromAlgebraic("e7")!!
        val e5 = Square.fromAlgebraic("e5")!!
        val move2 = Move(from = e7, to = e5)

        val success2 = board.makeMove(move2)
        assertTrue(success2)
        assertEquals(PieceColor.WHITE, board.activeColor)
    }

    @Test
    fun testScholarsMate() {
        val board = ChessBoard.createStartingBoard()
        // 1. e4 e5
        board.makeMove(Move(Square.fromAlgebraic("e2")!!, Square.fromAlgebraic("e4")!!))
        board.makeMove(Move(Square.fromAlgebraic("e7")!!, Square.fromAlgebraic("e5")!!))

        // 2. Bc4 Nc6
        board.makeMove(Move(Square.fromAlgebraic("f1")!!, Square.fromAlgebraic("c4")!!))
        board.makeMove(Move(Square.fromAlgebraic("b8")!!, Square.fromAlgebraic("c6")!!))

        // 3. Qh5 Nf6
        board.makeMove(Move(Square.fromAlgebraic("d1")!!, Square.fromAlgebraic("h5")!!))
        board.makeMove(Move(Square.fromAlgebraic("g8")!!, Square.fromAlgebraic("f6")!!))

        // 4. Qxf7#
        val success = board.makeMove(Move(Square.fromAlgebraic("h5")!!, Square.fromAlgebraic("f7")!!))
        assertTrue(success)

        assertTrue(board.isInCheck(PieceColor.BLACK))
        assertEquals(GameStatus.CHECKMATE, board.getGameStatus())
        val blackMoves = board.generateLegalMoves(PieceColor.BLACK)
        assertEquals(0, blackMoves.size)
    }

    @Test
    fun testCastling() {
        val board = ChessBoard.createStartingBoard()
        // Clear path for White king-side castle: 1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5
        board.makeMove(Move(Square.fromAlgebraic("e2")!!, Square.fromAlgebraic("e4")!!))
        board.makeMove(Move(Square.fromAlgebraic("e7")!!, Square.fromAlgebraic("e5")!!))
        board.makeMove(Move(Square.fromAlgebraic("g1")!!, Square.fromAlgebraic("f3")!!))
        board.makeMove(Move(Square.fromAlgebraic("b8")!!, Square.fromAlgebraic("c6")!!))
        board.makeMove(Move(Square.fromAlgebraic("f1")!!, Square.fromAlgebraic("c4")!!))
        board.makeMove(Move(Square.fromAlgebraic("f8")!!, Square.fromAlgebraic("c5")!!))

        // White king can castle: e1 -> g1
        val whiteKingMoves = board.getLegalMovesForSquare(Square.fromAlgebraic("e1")!!)
        val castleMove = whiteKingMoves.find { it.to == Square.fromAlgebraic("g1")!! }
        assertNotNull(castleMove)
        assertTrue(castleMove!!.isCastling)

        // Make castling move
        val castled = board.makeMove(castleMove)
        assertTrue(castled)

        // Verify King is on g1 and Rook is on f1
        val king = board.getPiece(Square.fromAlgebraic("g1")!!)
        val rook = board.getPiece(Square.fromAlgebraic("f1")!!)
        assertNotNull(king)
        assertEquals(PieceType.KING, king!!.type)
        assertNotNull(rook)
        assertEquals(PieceType.ROOK, rook!!.type)
    }

    @Test
    fun testEnPassant() {
        val board = ChessBoard.createStartingBoard()
        // 1. e4 a6 2. e5 d5
        board.makeMove(Move(Square.fromAlgebraic("e2")!!, Square.fromAlgebraic("e4")!!))
        board.makeMove(Move(Square.fromAlgebraic("a7")!!, Square.fromAlgebraic("a6")!!))
        board.makeMove(Move(Square.fromAlgebraic("e4")!!, Square.fromAlgebraic("e5")!!))
        board.makeMove(Move(Square.fromAlgebraic("d7")!!, Square.fromAlgebraic("d5")!!))

        // White pawn on e5 can capture en passant on d6
        val epSquare = Square.fromAlgebraic("d6")!!
        assertEquals(epSquare, board.enPassantTarget)

        val legalMoves = board.getLegalMovesForSquare(Square.fromAlgebraic("e5")!!)
        val epMove = legalMoves.find { it.to == epSquare }
        assertNotNull(epMove)
        assertTrue(epMove!!.isEnPassant)

        // Execute en passant
        board.makeMove(epMove)
        // Verify black pawn on d5 was captured
        val d5Piece = board.getPiece(Square.fromAlgebraic("d5")!!)
        assertEquals(null, d5Piece)
        // Verify white pawn is now on d6
        val d6Piece = board.getPiece(Square.fromAlgebraic("d6")!!)
        assertNotNull(d6Piece)
        assertEquals(PieceType.PAWN, d6Piece!!.type)
        assertEquals(PieceColor.WHITE, d6Piece.color)
    }

    @Test
    fun testAiFindsLegalMove() = runBlocking {
        val board = ChessBoard.createStartingBoard()
        board.makeMove(Move(Square.fromAlgebraic("e2")!!, Square.fromAlgebraic("e4")!!))

        val bestMove = ChessEngineAi.findBestMove(board, AiDifficulty.LEVEL_3)
        assertNotNull(bestMove)
        val isLegal = board.generateLegalMoves(PieceColor.BLACK).any {
            it.from == bestMove!!.from && it.to == bestMove.to
        }
        assertTrue(isLegal)
    }
}
