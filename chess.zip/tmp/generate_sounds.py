import wave
import struct
import math
import random
import os

SAMPLE_RATE = 44100

def write_wav(filename, samples):
    with wave.open(filename, 'wb') as wav_file:
        wav_file.setnchannels(1) # mono
        wav_file.setsampwidth(2) # 16-bit
        wav_file.setframerate(SAMPLE_RATE)
        
        # Clip and convert to 16-bit signed integers
        data = bytearray()
        for s in samples:
            val = max(-1.0, min(1.0, s))
            int_val = int(val * 32767.0)
            data.extend(struct.pack('<h', int_val))
        wav_file.writeframes(data)
    print(f"Generated {filename} ({len(samples)} samples)")

output_dir = "/app/src/main/res/raw"
os.makedirs(output_dir, exist_ok=True)

# 1. move.wav: Soft wooden piece placement on wood/felt
def gen_move():
    duration = 0.09
    num_samples = int(duration * SAMPLE_RATE)
    samples = []
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        # Envelope: very sharp attack, fast natural exponential decay
        env = math.exp(-t * 60.0)
        # Wood resonance body
        f1 = 220.0
        f2 = 460.0
        f3 = 920.0
        tone = (math.sin(2 * math.pi * f1 * t) * 0.55 +
                math.sin(2 * math.pi * f2 * t) * 0.25 +
                math.sin(2 * math.pi * f3 * t) * 0.10)
        # Initial tactile click (first 5ms)
        noise = (random.random() * 2.0 - 1.0) * math.exp(-t * 500.0) * 0.35
        sample = (tone + noise) * env * 0.70
        samples.append(sample)
    return samples

# 2. capture.wav: Satisfying wood-on-wood capture tap
def gen_capture():
    duration = 0.13
    num_samples = int(duration * SAMPLE_RATE)
    samples = []
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        # Primary strike at t=0
        env1 = math.exp(-t * 55.0)
        s1 = (math.sin(2 * math.pi * 310.0 * t) * 0.50 +
              math.sin(2 * math.pi * 680.0 * t) * 0.25 +
              (random.random() * 2.0 - 1.0) * math.exp(-t * 400.0) * 0.40) * env1
        
        # Secondary landing strike at t=0.035
        s2 = 0.0
        if t >= 0.035:
            dt = t - 0.035
            env2 = math.exp(-dt * 65.0)
            s2 = (math.sin(2 * math.pi * 210.0 * dt) * 0.45 +
                  (random.random() * 2.0 - 1.0) * math.exp(-dt * 500.0) * 0.25) * env2
        
        sample = (s1 * 0.65 + s2 * 0.50) * 0.85
        samples.append(sample)
    return samples

# 3. castle.wav: Gentle double-move wood tap
def gen_castle():
    duration = 0.18
    num_samples = int(duration * SAMPLE_RATE)
    samples = []
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        # First piece (King)
        s1 = 0.0
        env1 = math.exp(-t * 60.0)
        s1 = (math.sin(2 * math.pi * 230.0 * t) * 0.50 +
              (random.random() * 2.0 - 1.0) * math.exp(-t * 450.0) * 0.30) * env1
        
        # Second piece (Rook) at t=0.070
        s2 = 0.0
        if t >= 0.070:
            dt = t - 0.070
            env2 = math.exp(-dt * 60.0)
            s2 = (math.sin(2 * math.pi * 260.0 * dt) * 0.50 +
                  (random.random() * 2.0 - 1.0) * math.exp(-dt * 450.0) * 0.30) * env2
        
        sample = (s1 + s2) * 0.65
        samples.append(sample)
    return samples

# 4. check.wav: Refined, non-intrusive warm dual harmonic chime
def gen_check():
    duration = 0.38
    num_samples = int(duration * SAMPLE_RATE)
    samples = []
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        # Tone 1: C5 (523.25 Hz)
        env1 = math.exp(-t * 9.0)
        tone1 = (math.sin(2 * math.pi * 523.25 * t) * 0.60 +
                 math.sin(2 * math.pi * 1046.50 * t) * 0.20) * env1
        
        # Tone 2: E5 (659.25 Hz) entering at t=0.06s
        tone2 = 0.0
        if t >= 0.06:
            dt = t - 0.06
            env2 = math.exp(-dt * 9.0)
            tone2 = (math.sin(2 * math.pi * 659.25 * dt) * 0.60 +
                     math.sin(2 * math.pi * 1318.50 * dt) * 0.20) * env2
        
        sample = (tone1 * 0.45 + tone2 * 0.45) * 0.60
        samples.append(sample)
    return samples

# 5. game_over.wav: Serene, elegant harmonic resolution chord
def gen_game_over():
    duration = 0.70
    num_samples = int(duration * SAMPLE_RATE)
    samples = []
    chord_freqs = [261.63, 329.63, 392.00, 523.25] # C Major triad
    for i in range(num_samples):
        t = i / SAMPLE_RATE
        # Smooth gentle attack (0.04s) and warm natural decay
        attack = min(1.0, t / 0.04)
        decay = math.exp(-t * 4.5)
        env = attack * decay
        
        tone = 0.0
        for f in chord_freqs:
            tone += math.sin(2 * math.pi * f * t) * 0.22
            tone += math.sin(2 * math.pi * f * 2.0 * t) * 0.05
        
        sample = tone * env * 0.60
        samples.append(sample)
    return samples

write_wav(os.path.join(output_dir, "chess_move.wav"), gen_move())
write_wav(os.path.join(output_dir, "chess_capture.wav"), gen_capture())
write_wav(os.path.join(output_dir, "chess_castle.wav"), gen_castle())
write_wav(os.path.join(output_dir, "chess_check.wav"), gen_check())
write_wav(os.path.join(output_dir, "chess_game_over.wav"), gen_game_over())
print("All audio files generated successfully.")
